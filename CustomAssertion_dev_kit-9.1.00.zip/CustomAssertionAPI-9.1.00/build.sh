#!/bin/sh
# builds the jar file puts it in build directory

export ANT_HOME=./tools/ant
./tools/ant/ant "$@"

