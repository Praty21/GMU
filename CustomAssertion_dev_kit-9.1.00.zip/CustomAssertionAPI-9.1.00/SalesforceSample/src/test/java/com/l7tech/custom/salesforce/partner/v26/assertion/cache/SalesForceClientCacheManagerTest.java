package com.l7tech.custom.salesforce.partner.v26.assertion.cache;

import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceClient;
import com.l7tech.policy.assertion.ext.password.SecurePasswordServices;
import com.salesforce.jaxws.DescribeSObjectResult;
import com.salesforce.jaxws.LoginResult;
import com.l7tech.custom.salesforce.partner.v26.assertion.util.Config;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;

import static com.l7tech.custom.salesforce.partner.v26.assertion.cache.SalesForceClientCacheManager.*;
import static com.l7tech.custom.salesforce.partner.v26.assertion.util.Config.*;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Salesforce client cache manager unit tests.
 */
@RunWith(MockitoJUnitRunner.class)
public class SalesForceClientCacheManagerTest {
    private final static String connectionKey = "connectionKey";
    private final static String userName = "userName";
    private final static String password = "password";
    private final static String securityToken = "securityToken";
    final String passwordId = "passwordId";
    final String securityTokenId = "securityTokenId";
    private final SalesForceClientCacheKey cacheKey = new SalesForceClientCacheKey(connectionKey, userName, passwordId, securityTokenId);

    @Mock private static SalesForceClient salesForceClient;
    @Mock private Config config;
    @Mock private SecurePasswordServices securePasswordServices;
    @Mock private SalesForceClientCacheManager.SalesForceClientFactory salesForceClientFactory;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void doWithSalesforceClient() throws Exception {
        when(config.getProperty(SALESFORCE_CONNECTION_CACHE_MAX_AGE_PROPERTY, String.valueOf(DEFAULT_CONNECTION_MAX_AGE))).thenReturn("10");
        when(config.getTimeUnitProperty(SALESFORCE_CONNECTION_CACHE_MAX_AGE_PROPERTY, DEFAULT_CONNECTION_MAX_AGE)).thenReturn(10L);
        when(config.getTimeUnitProperty(SALESFORCE_CONNECTION_CACHE_MAX_IDLE_PROPERTY, DEFAULT_CONNECTION_MAX_IDLE)).thenReturn(5L);
        when(config.getIntegerProperty(SALESFORCE_CONNECTION_CACHE_MAX_SIZE_PROPERTY, DEFAULT_CONNECTION_CACHE_SIZE)).thenReturn(100);
        when(securePasswordServices.decryptPassword(passwordId)).thenReturn(password);
        when(securePasswordServices.decryptPassword(securityTokenId)).thenReturn(securityToken);

        SalesForceClientCacheManager salesForceClientCacheManager = SalesForceClientCacheManager.getInstance(config, securePasswordServices);

        // isolate Salesforce client's dependency on a live Salesforce back-end
        when(salesForceClientFactory.create()).thenReturn(salesForceClient);
        salesForceClientCacheManager.setSalesForceClientFactory(salesForceClientFactory);
        LoginResult loginResult = new LoginResult();
        when(salesForceClient.login(userName, password, securityToken)).thenReturn(loginResult);
        when(salesForceClient.describeGlobal()).thenReturn(new ArrayList<String>(0));
        when(salesForceClient.describeSObject(anyString())).thenReturn(new DescribeSObjectResult());

        // make multiple client calls in one callback
        salesForceClientCacheManager.doWithSalesforceClient(cacheKey, new SalesForceClientCacheManager.SalesforceClientTaskCallback() {
            public void doWork(SalesForceClient salesForceClient) throws Exception {
                // mock calls using Salesforce client
                salesForceClient.describeGlobal();
                salesForceClient.describeSObject("sObjectToDescribe");
            }
        }
        );

        // make another client call in a separate callback
        salesForceClientCacheManager.doWithSalesforceClient(cacheKey, new SalesForceClientCacheManager.SalesforceClientTaskCallback() {
            public void doWork(SalesForceClient salesForceClient) throws Exception {
                salesForceClient.describeSObject("sObjectToDescribe");
            }
        }
        );

        // make sure we only login once
        verify(salesForceClient, times(1)).login(userName, password, securityToken);

        // TODO make sure logout happens if cache has been invalidated
        // salesForceClientCacheManager.invalidate(cacheKey);
        // verify(salesForceClient, times(1)).logout();

        // TODO clean timer task with config default override
    }
}
