package com.l7tech.custom.salesforce.partner.v26.assertion.cache;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Test Salesforce client cache key.
 */
public class SalesForceClientCacheKeyTest {

    @Test
    public void compareCacheKey() {
        final String connectionKey = "connectionKey";
        final String userName = "userName";
        final String passwordId = "passwordId";
        final String securityTokenId = "securityTokenId";

        SalesForceClientCacheKey cacheKey1 = new SalesForceClientCacheKey(connectionKey, userName, passwordId, securityTokenId);
        SalesForceClientCacheKey cacheKey2 = new SalesForceClientCacheKey(connectionKey, userName, passwordId, securityTokenId);

        assertEquals(cacheKey1, cacheKey2);
        assertTrue(cacheKey1.toString().equals(cacheKey2.toString()));
        assertEquals(cacheKey1.hashCode(), cacheKey2.hashCode());
    }
}
