package com.l7tech.custom.salesforce.partner.v26.assertion;

import com.salesforce.jaxws.InvalidIdFault_Exception;
import com.salesforce.jaxws.LoginFault_Exception;
import org.junit.Ignore;
import org.junit.Test;

import java.net.MalformedURLException;
import java.net.UnknownHostException;

import static junit.framework.Assert.*;

public class SalesForceClientTest {
    /**
     * This integration test requires a running Gateway with service at http://gatewayHostName:8080/salesforce-partner-v26.wsdl.
     * If Gateway service not running, you'll see this exception:
     *      WebServiceException: {urn:partner.soap.sforce.com}SforceService is not a valid service. Valid services are:
     */
    @Ignore("Integration Test")
    @Test
    public void createClient() throws MalformedURLException, UnknownHostException {
        SalesForceClient salesForceClient = new SalesForceClient();
        try {
            salesForceClient.login("invalidUserName", "invalidPassword", "invalidSecurityToken");
            fail("Salesforce.com login expected to fail with invalid credentials.");
        } catch (LoginFault_Exception e) {
            // do nothing expected exception
        } catch (InvalidIdFault_Exception e) {
            // do nothing expected exception
        }
    }
}
