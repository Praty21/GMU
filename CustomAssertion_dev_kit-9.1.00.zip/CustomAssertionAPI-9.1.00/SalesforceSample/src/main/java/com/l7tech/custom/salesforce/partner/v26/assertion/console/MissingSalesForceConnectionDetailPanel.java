package com.l7tech.custom.salesforce.partner.v26.assertion.console;

import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceConnection;

import javax.swing.*;
import java.awt.*;

/**
 * Displays the missing Salesforce Connection details.
 */
public class MissingSalesForceConnectionDetailPanel extends JPanel {
    private JTextField nameTextField;
    private JTextField descriptionTextField;
    private JTextField usernameTextField;
    private JTextField editableTextField;
    private JPanel mainPanel;

    public MissingSalesForceConnectionDetailPanel(final SalesForceConnection connection) {
        setLayout(new BorderLayout());

        nameTextField.setText(connection.getConnectionName());
        descriptionTextField.setText(connection.getDescription());
        usernameTextField.setText(connection.getUsername());
        editableTextField.setText(connection.isEnabled() ? "Yes" : "No");

        this.add(mainPanel);
    }
}
