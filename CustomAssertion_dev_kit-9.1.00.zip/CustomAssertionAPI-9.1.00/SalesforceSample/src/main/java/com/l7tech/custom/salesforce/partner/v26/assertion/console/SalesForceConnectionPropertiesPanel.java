package com.l7tech.custom.salesforce.partner.v26.assertion.console;

import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceConnection;
import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceCustomExtensionInterface;
import com.l7tech.policy.assertion.ext.ServiceException;
import com.l7tech.policy.assertion.ext.cei.CustomExtensionInterfaceFinder;
import com.l7tech.policy.assertion.ext.commonui.CommonUIServices;
import com.l7tech.policy.assertion.ext.commonui.CustomSecurePasswordPanel;
import com.l7tech.policy.assertion.ext.entity.panels.CustomEntityCreateUiPanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Map;

/**
 * Panel for modifying Salesforce connection, before creating it.
 */
public class SalesForceConnectionPropertiesPanel extends CustomEntityCreateUiPanel<SalesForceConnection> {
    private static final long serialVersionUID = -992386379343735371L;

    private JPanel mainPanel;
    private JTextField nameTextField;
    private JTextField descriptionTextField;
    private JTextField usernameTextField;
    private JPanel passwordPanelHolder;
    private JPanel securityTokenPanelHolder;
    private JCheckBox enabledCheckBox;
    private JButton testSettingsButton;

    private CustomSecurePasswordPanel customSecurePasswordPanel;
    private CustomSecurePasswordPanel customSecureSecurityTokenPanel;

    private SalesForceConnection connection;
    private Map consoleContext;

    public SalesForceConnectionPropertiesPanel() {
        setLayout(new BorderLayout());
        this.add(mainPanel);
    }

    /**
     * Test settings button listener.<br/>
     * Make sure whether we can login to Salesforce using provided username, password and token.
     */
    private void onTestSettings() {
        // Name, Username, Password, and Security token are required.
        //
        if (nameTextField.getText() == null || nameTextField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "The Name field must not be empty.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (usernameTextField.getText() == null || usernameTextField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "The Username field must not be empty.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!customSecurePasswordPanel.isItemSelected()) {
            JOptionPane.showMessageDialog(this,
                    "The Password field must be selected.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!customSecureSecurityTokenPanel.isItemSelected()) {
            JOptionPane.showMessageDialog(this,
                    "The Security Token field must be selected.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean isTestConnectionSuccessful;
        try {
            isTestConnectionSuccessful =
                    getExtensionInterface().testConnection(
                            usernameTextField.getText().trim(),
                            customSecurePasswordPanel.getSelectedItem(),
                            customSecureSecurityTokenPanel.getSelectedItem());
        } catch (Exception e) {
            isTestConnectionSuccessful = false;
        }

        if (isTestConnectionSuccessful) {
            JOptionPane.showMessageDialog(this,
                    "The Gateway has successfully verified this Salesforce Connection settings.",
                    "Salesforce Connection Test Successful",
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                    "Unable to verify this Salesforce Connection settings.",
                    "Salesforce Connection Test Failed",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override
    public void initialize(final SalesForceConnection entity) {
        if (entity == null) {
            throw new IllegalArgumentException("entity cannot be null");
        }
        this.connection = entity;

        // Password Panel.
        //
        customSecurePasswordPanel = getCommonUIServices().createPasswordComboBoxPanel(null);
        customSecurePasswordPanel.addListener(new CustomSecurePasswordPanel.ManagePasswordsDialogClosedListener() {
            @Override
            public void onClosed() {
                // Reload the security token combo box.
                //
                customSecureSecurityTokenPanel.reloadComboBox();
            }
        });
        passwordPanelHolder.setLayout(new BorderLayout());
        passwordPanelHolder.add(customSecurePasswordPanel.getPanel(), BorderLayout.CENTER);

        // Security Token Panel.
        //
        customSecureSecurityTokenPanel = getCommonUIServices().createPasswordComboBoxPanel(null);
        customSecureSecurityTokenPanel.setDisplayManagePasswordsButton(false);
        securityTokenPanelHolder.setLayout(new BorderLayout());
        securityTokenPanelHolder.add(customSecureSecurityTokenPanel.getPanel(), BorderLayout.CENTER);

        testSettingsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onTestSettings();
            }
        });

        // Populate fields
        //
        nameTextField.setText(connection.getConnectionName());
        descriptionTextField.setText(connection.getDescription());
        usernameTextField.setText(connection.getUsername());
        if (connection.getPasswordId() != null) {
            customSecurePasswordPanel.setSelectedItem(connection.getPasswordId());
        }
        if (connection.getSecurityTokenId() != null) {
            customSecureSecurityTokenPanel.setSelectedItem(connection.getSecurityTokenId());
        }
        enabledCheckBox.setSelected(connection.isEnabled());
    }

    /**
     * @return {@code SalesForceConnection} object if all properties are validated or {@code null} otherwise.
     */
    @Override
    public SalesForceConnection validateEntity() {
        // Name, Username, Password, and Security token are required.
        //
        if (nameTextField.getText() == null || nameTextField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "The Name field must not be empty.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }

        if (usernameTextField.getText() == null || usernameTextField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "The Username field must not be empty.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }

        if (!customSecurePasswordPanel.isItemSelected()) {
            JOptionPane.showMessageDialog(this,
                    "The Password field must be selected.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }

        if (!customSecureSecurityTokenPanel.isItemSelected()) {
            JOptionPane.showMessageDialog(this,
                    "The Security Token field must be selected.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return null;
        }

        connection.setConnectionName(nameTextField.getText().trim());
        connection.setDescription(descriptionTextField.getText().trim());
        connection.setUsername(usernameTextField.getText().trim());
        connection.setPasswordId(customSecurePasswordPanel.getSelectedItem());
        connection.setSecurityTokenId(customSecureSecurityTokenPanel.getSelectedItem());
        connection.setEnabled(enabledCheckBox.isSelected());

        return connection;
    }

    @Override
    public void setConsoleContextUsed(final Map consoleContext) {
        this.consoleContext = consoleContext;
    }

    private CommonUIServices getCommonUIServices() {
        if (consoleContext == null) {
            throw new IllegalStateException("consoleContext cannot be null");
        }
        return (CommonUIServices) consoleContext.get(CommonUIServices.CONSOLE_CONTEXT_KEY);
    }

    private SalesForceCustomExtensionInterface getExtensionInterface() throws ServiceException {
        if (consoleContext == null) {
            throw new IllegalStateException("consoleContext cannot be null");
        }
        SalesForceCustomExtensionInterface salesForceCustomExtensionInterface = null;
        CustomExtensionInterfaceFinder extensionInterfaceFinder = (CustomExtensionInterfaceFinder) consoleContext.get(CustomExtensionInterfaceFinder.CONSOLE_CONTEXT_KEY);
        if (extensionInterfaceFinder != null) {
            salesForceCustomExtensionInterface = extensionInterfaceFinder.getExtensionInterface(SalesForceCustomExtensionInterface.class);
        }
        return salesForceCustomExtensionInterface;
    }
}
