package com.l7tech.custom.salesforce.partner.v26.assertion;

import org.springframework.transaction.annotation.Transactional;

/**
 * Server side functions allowed for Salesforce.
 */

public interface SalesForceCustomExtensionInterface {
    @Transactional(readOnly=true)
    String[] describeGlobal(String connectionKey) throws Exception;

    @Transactional(readOnly=true)
    boolean testConnection(String userName, String passwordId, String securityTokenId) throws Exception;
}
