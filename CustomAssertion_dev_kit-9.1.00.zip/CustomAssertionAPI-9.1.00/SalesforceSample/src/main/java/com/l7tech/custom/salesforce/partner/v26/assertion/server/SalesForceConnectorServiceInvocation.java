package com.l7tech.custom.salesforce.partner.v26.assertion.server;

import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceClient;
import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceConnection;
import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceConnectorCustomAssertion;
import com.l7tech.custom.salesforce.partner.v26.assertion.cache.SalesForceClientCacheKey;
import com.l7tech.custom.salesforce.partner.v26.assertion.cache.SalesForceClientCacheManager;
import com.l7tech.custom.salesforce.partner.v26.assertion.util.Config;
import com.l7tech.custom.salesforce.partner.v26.assertion.util.SalesForceConnectionUtils;
import com.l7tech.policy.assertion.ext.*;

import com.l7tech.policy.assertion.ext.message.*;
import com.l7tech.policy.assertion.ext.message.format.CustomMessageFormat;
import com.l7tech.policy.assertion.ext.message.format.NoSuchMessageFormatException;
import com.l7tech.policy.assertion.ext.message.knob.CustomPartsKnob;
import com.l7tech.policy.assertion.ext.message.knob.NoSuchKnobException;
import com.l7tech.policy.assertion.ext.password.SecurePasswordServices;
import com.l7tech.policy.assertion.ext.store.KeyValueStore;
import com.l7tech.policy.assertion.ext.store.KeyValueStoreServices;
import com.l7tech.policy.variable.NoSuchVariableException;
import com.l7tech.policy.variable.VariableNotSettableException;
import com.salesforce.jaxws.DescribeSObjectResult;
import com.salesforce.jaxws.Field;
import com.salesforce.jaxws.InvalidIdFault_Exception;
import com.salesforce.jaxws.LoginFault_Exception;

import java.io.*;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class SalesForceConnectorServiceInvocation extends ServiceInvocation {
    private static final Logger logger = Logger.getLogger(SalesForceConnectorServiceInvocation.class.getName());

    /**
     * Indicate whether the SSG will go through all message parts and load them in memory,
     * so that they will be available in the context-map as key <code>messageParts</code>.
     * <p/>
     * We are going to override this method and return false in order to avoid unnecessary memory usage.
     * We'll use <code>CustomPartsKnob</code> to access the message parts only when needed.
     */
    @Override
    public boolean loadsMessagePartsIntoMemory() {
        return false;
    }

    @Override
    public CustomAssertionStatus checkRequest(final CustomPolicyContext policyContext) {
        logger.log(Level.FINE, "SalesForceConnectorServiceInvocation.checkRequest(...)");

        if (!(customAssertion instanceof SalesForceConnectorCustomAssertion)) {
            logger.log(Level.SEVERE,
                    String.format("customAssertion must be of type [{%s}], but it is of type [{%s}] instead",
                            SalesForceConnectorCustomAssertion.class.getSimpleName(),
                            customAssertion.getClass().getSimpleName()));
            return CustomAssertionStatus.FAILED;
        }

        final SalesForceConnectorCustomAssertion sfdcAssertion;
        try {
            sfdcAssertion = (SalesForceConnectorCustomAssertion) customAssertion;
        } catch (ClassCastException e) {
            logger.log(Level.WARNING, "ClassCastException Exception: ", e);
            return CustomAssertionStatus.FAILED;
        }

        if (Config.getInstance().getBooleanProperty(Config.SALESFORCE_DEV_DEBUG_ALWAYS_RETURN_FAILED_PROPERTY)) {
            return CustomAssertionStatus.FAILED;
        }

        ServiceFinder serviceFinder = (ServiceFinder) policyContext.getContext().get("serviceFinder");
        SecurePasswordServices securePasswordServices = serviceFinder.lookupService(SecurePasswordServices.class);
        KeyValueStoreServices keyValueStoreServices = serviceFinder.lookupService(KeyValueStoreServices.class);
        KeyValueStore keyValueStore = keyValueStoreServices.getKeyValueStore();

        SalesForceClientCacheManager salesForceClientCacheManager = SalesForceClientCacheManager.getInstance(Config.getInstance(), securePasswordServices);

        // extract needed message formats
        CustomMessageFormat<Document> xmlFormat;
        CustomMessageFormat<CustomJsonData> jsonFormat;
        CustomMessageFormat<InputStream> iStreamFormat;
        try {
            xmlFormat = policyContext.getFormats().getFormat(Document.class);
            jsonFormat = policyContext.getFormats().getFormat(CustomJsonData.class);

            // alternatively, you can use one of the convenient methods e.g. for InputStream
            // iStreamFormat = policyContext.getFormats().getFormat(InputStream.class);
            // can be replaced with:
            iStreamFormat = policyContext.getFormats().getStreamFormat();
        } catch (NoSuchMessageFormatException e) {
            // shouldn't happen so fail
            logger.log(Level.SEVERE, "sourceMessage.extract(...) --- NoSuchMessageFormatException Exception: ", e);
            return CustomAssertionStatus.FAILED;
        }

        // get the source target message
        CustomMessage sourceMessage;
        try {
            sourceMessage = policyContext.getTargetMessage(sfdcAssertion.getSourceTarget());
        } catch (NoSuchVariableException e) {
            // we cannot continue without the source message
            logger.log(Level.SEVERE, "policyContext.getTargetMessage(" + sfdcAssertion.getDestinationTarget().getTargetMessageVariable() + ") failed --- NoSuchVariableException Exception: ", e);
            return CustomAssertionStatus.FAILED;
        } catch (VariableNotSettableException e) {
            // we cannot continue without the source message
            logger.log(Level.SEVERE, "policyContext.getTargetMessage(" + sfdcAssertion.getDestinationTarget().getTargetMessageVariable() + ") failed --- VariableNotSettableException Exception: ", e);
            return CustomAssertionStatus.FAILED;
        }

        // Read message content using CustomMessageFormat extraction functionality.
        try {
            logMessageContent(xmlFormat.extract(sourceMessage)); // if the content is XML
            // alternatively you can use:
            //sourceMessage.extract(xmlFormat)

            logMessageContent(jsonFormat.extract(sourceMessage)); // if the content is JSON
            logMessageContent(iStreamFormat.extract(sourceMessage)); // for InputStream content
        } catch (CustomMessageAccessException e) {
            logger.log(Level.WARNING, "sourceMessage.extract(...) --- CustomMessageAccessException Exception: ", e);
        }

        // log if the messageParts context map is present
        if (loadsMessagePartsIntoMemory()) {
            logger.log(Level.INFO, policyContext.getContext().get("messageParts") == null ? "messageParts context map is missing NOT OK" : "messageParts context map is present, OK");
        } else {
            logger.log(Level.INFO, policyContext.getContext().get("messageParts") == null ? "messageParts context map is missing OK" : "messageParts context map is present, NOT OK");
        }

        // extract message multipart parts
        try {
            // will always return at least one part, even if the message is single-part
            CustomPartsKnob messageParts = sourceMessage.getKnob(CustomPartsKnob.class);

            logger.info("Message parts:");
            int count = 0;
            for (CustomPartsKnob.Part part : messageParts) {
                logMessagePartContent(part, count++);
            }
        } catch (NoSuchKnobException e) {
            logger.log(Level.WARNING, "sourceMessage.getKnob(...) --- NoSuchKnobException Exception: ", e);
        } catch (IOException e) {
            logger.log(Level.WARNING, "part.getInputStream(...) --- IOException Exception: ", e);
        }

        String connectionKey = sfdcAssertion.getConnectionKey();
        byte[] value = keyValueStore.get(connectionKey);
        if (value == null) {
            logger.log(Level.SEVERE, "Cannot find SalesForce Connection with the specified key: " + connectionKey);
            return CustomAssertionStatus.FAILED;
        }

        SalesForceConnection connection = SalesForceConnectionUtils.fromBytes(value);
        if (connection == null) {
            logger.log(Level.SEVERE, "SalesForce Connection with the specified key cannot be de-serialized: " + connectionKey);
            return CustomAssertionStatus.FAILED;
        }

        if (!connection.isEnabled()) {
            logger.log(Level.SEVERE, "SalesForce Connection with the specified key is disabled: " + connectionKey);
            return CustomAssertionStatus.FAILED;
        }

        String username = connection.getUsername();
        String passwordId = connection.getPasswordId();
        String securityTokenId = connection.getSecurityTokenId();
        final SalesForceClientCacheKey cacheKey = new SalesForceClientCacheKey(connectionKey, replaceVars(username, policyContext), passwordId, securityTokenId);

        //noinspection Convert2Diamond
        final List<Field> describeSObjectResultFields = new ArrayList<Field>(0);
        try {
            // let cache manager handle all client caching
            final String sObjectToDescribe = sfdcAssertion.getsObject();
            salesForceClientCacheManager.doWithSalesforceClient(cacheKey, new SalesForceClientCacheManager.SalesforceClientTaskCallback() {
                public void doWork(SalesForceClient salesForceClient) throws Exception {

                    // save session ID and URL
                    policyContext.setVariable(sfdcAssertion.getSessionIdVariable(), salesForceClient.getLoginResult().getSessionId());
                    policyContext.setVariable(sfdcAssertion.getSessionUrlVariable(), salesForceClient.getLoginResult().getServerUrl());

                    // call describeSObject and log the fields in the sObject
                    DescribeSObjectResult describeSObjectResult = salesForceClient.describeSObject(sObjectToDescribe);
                    describeSObjectResultFields.addAll(describeSObjectResult.getFields());
                }}
            );
        } catch (Exception e) {
            // invalidate this connection from cache
            salesForceClientCacheManager.invalidate(cacheKey);

            if (e instanceof MalformedURLException) {
                return CustomAssertionStatus.FALSIFIED;
            } else if (e instanceof LoginFault_Exception || e instanceof InvalidIdFault_Exception) {
                return CustomAssertionStatus.UNAUTHORIZED;
            } else {
                return CustomAssertionStatus.FALSIFIED;
            }
        }

        // check for context variables from input fields and expand them
        if (sfdcAssertion.getExpandContextVariable() != null) {
            String expandedVariable = replaceVars(sfdcAssertion.getExpandContextVariable(), policyContext);
            logger.log(Level.INFO, "Expanded '" + sfdcAssertion.getExpandContextVariable() + "' to '" + expandedVariable + "'");
            policyContext.setVariable(sfdcAssertion.getVariablePrefix()+".expanded", expandedVariable);
        }

        // convert the result into String
        final StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<describeSObjectResultFields>");
        for (int i = 0; i < describeSObjectResultFields.size(); i++) {
            final Field field =  describeSObjectResultFields.get(i);
            stringBuilder.append(field.getName());
            if (i < describeSObjectResultFields.size() - 1 ) {
                stringBuilder.append(", ");
            }
        }
        stringBuilder.append("</describeSObjectResultFields>");
        String strOutput = stringBuilder.toString();

        // convert the string result into DOM Document
        Document outputDoc;
        try {
            final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            final DocumentBuilder builder = factory.newDocumentBuilder();
            outputDoc = builder.parse(new InputSource(new StringReader(stringBuilder.toString())));
        } catch (ParserConfigurationException e) {
            logger.log(Level.WARNING, "Failed to convert output string [" + strOutput + "] into DOM Document --- ParserConfigurationException Exception: ", e);
            return CustomAssertionStatus.FAILED;
        } catch (SAXException e) {
            logger.log(Level.WARNING, "Failed to convert output string [" + strOutput + "] into DOM Document --- SAXException Exception: ", e);
            return CustomAssertionStatus.FAILED;
        } catch (IOException e) {
            logger.log(Level.WARNING, "Failed to convert output string [" + strOutput + "] into DOM Document --- IOException Exception: ", e);
            return CustomAssertionStatus.FAILED;
        }

        // get the destination message target
        CustomMessage destMessage;
        try {
            destMessage = policyContext.getTargetMessage(sfdcAssertion.getDestinationTarget());
        } catch (NoSuchVariableException e) {
            logger.log(Level.WARNING, "policyContext.getTargetMessage(" + sfdcAssertion.getDestinationTarget().getTargetMessageVariable() + ") failed --- NoSuchVariableException Exception: ", e);
            return CustomAssertionStatus.FALSIFIED;
        } catch (VariableNotSettableException e) {
            logger.log(Level.WARNING, "policyContext.getTargetMessage(" + sfdcAssertion.getDestinationTarget().getTargetMessageVariable() + ") failed --- VariableNotSettableException Exception: ", e);
            return CustomAssertionStatus.FALSIFIED;
        }

        // write the outputDoc into destination message target
        try {
            // since this is a DOM Document we'll use the xml format
            xmlFormat.overwrite(destMessage, outputDoc);
            // alternatively you can use
            //destMessage.overwrite(xmlFormat, outputDoc);

            // if it was JSON, then:
            //jsonFormat.overwrite(destMessage, jsonOutput);

            // if we wanted to write the XML content as input-stream, then:
            //destMessage.setContentType(policyContext.createContentType("text/xml; charset=utf-8"));
            //iStreamFormat.overwrite(destMessage, new ByteArrayInputStream(strOutput.getBytes()));
        } catch (CustomMessageAccessException e) {
            logger.log(Level.WARNING, "destMessage.setDocument --- CustomMessageAccessException Exception: ", e);
            return CustomAssertionStatus.FALSIFIED;
        }

        this.readClusterWideProperties(policyContext);

        return CustomAssertionStatus.NONE;
    }

    /**
     * Logs certain message multipart <tt>part</tt>.
     *
     * @param part    the message multipart part to be logged.
     * @param i       the part ordinal possition in the message.
     */
    private void logMessagePartContent(CustomPartsKnob.Part part, int i) throws IOException {
        CustomContentType contentType = part.getContentType();
        InputStream inputStream = part.getInputStream();

        // log the multipart part's info
        logger.log(Level.INFO, "--------------------------------------------------------------");
        logger.log(Level.INFO, "Message part [" + i + "]");
        logger.log(Level.INFO, "Content-type: [" + contentType.getFullValue() + "]");
        logger.log(Level.INFO, "Content-body:");
        logMessageContent(inputStream);
        logger.log(Level.INFO, "--------------------------------------------------------------");
    }

    /**
     * Logs message content, based on supported message format representation class:
     * <ul>
     *     <li>XML: {@link Document}</li>
     *     <li>JSON: {@link com.l7tech.policy.assertion.ext.message.CustomJsonData CustomJsonData}</li>
     *     <li>InputStream : {@link InputSource}</li>
     * </ul>
     *
     * @param content    message content, represented by message format class.
     */
    private <T> void logMessageContent(final T content) {
        if (content == null) {
            logger.log(Level.FINE, "message content is null.");
        }

        // log XML content
        if (content instanceof Document) {
            final TransformerFactory tf = TransformerFactory.newInstance();
            Transformer transformer;
            try {
                transformer = tf.newTransformer();
                transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
                transformer.setOutputProperty(OutputKeys.INDENT, "yes");
                final StringWriter writer = new StringWriter();
                transformer.transform(new DOMSource((Document)content), new StreamResult(writer));
                final String output = writer.getBuffer().toString();//.replaceAll("\n|\r", "");
                logger.log(Level.INFO, "input Document string data:\n" + output);
            } catch (TransformerConfigurationException e) {
                logger.log(Level.WARNING, "TransformerConfigurationException Exception: ", e);
            } catch (TransformerException e) {
                logger.log(Level.WARNING, "TransformerException Exception: ", e);
            }
        // log JSON content
        } else if (content instanceof CustomJsonData) {
            logger.log(Level.INFO, "input JSON string data:\n" + ((CustomJsonData)content).getJsonData());
        // log InputStream content
        } else if (content instanceof InputStream) {
            try {
                final InputStreamReader reader = new InputStreamReader((InputStream)content);
                final char[] buffer = new char[16*1024]; // read in 16KB chunks
                final StringBuilder sb = new StringBuilder();
                int bytesRead;
                while ((bytesRead = reader.read(buffer, 0, buffer.length)) > 0) {
                    sb.append(buffer, 0, bytesRead);
                }
                logger.log(Level.INFO, "input stream data:\n" + sb.toString());
            } catch (IOException e) {
                logger.log(Level.WARNING, "IOException Exception: ", e);
            }
        }
    }

    private void readClusterWideProperties(final CustomPolicyContext customPolicyContext) {
        // Read cluster-wide properties
        // See https://jira.l7tech.com:8443/browse/FR-85
        //
        logger.log(Level.INFO, "Reading Cluster-Wide Property \"template.strictMode\": " + this.replaceVars("${gateway.template.strictMode}", customPolicyContext));
        logger.log(Level.INFO, "Reading Cluster-Wide Property \"template.defaultMultivalueDelimiter\": " + this.replaceVars("${gateway.template.defaultMultivalueDelimiter}", customPolicyContext));
        logger.log(Level.INFO, "Reading Cluster-Wide Property \"log.levels\": " + this.replaceVars("${gateway.log.levels}", customPolicyContext));
    }

    private String replaceVars(String stringData, final CustomPolicyContext customPolicyContext){
        return customPolicyContext.expandVariable(stringData);
    }
}
