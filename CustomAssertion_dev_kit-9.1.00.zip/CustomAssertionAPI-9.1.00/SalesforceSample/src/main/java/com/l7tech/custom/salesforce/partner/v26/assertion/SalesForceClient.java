package com.l7tech.custom.salesforce.partner.v26.assertion;

import com.salesforce.jaxws.*;
import com.sun.xml.ws.developer.WSBindingProvider;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SalesForceClient {
    private static final Logger logger = Logger.getLogger(SalesForceClient.class.getName());

    private final Soap service;
    private LoginResult loginResult;

    public SalesForceClient() {
        service = new SforceService(getClass().getClassLoader().getResource("salesforce-partner-v26.wsdl"), new QName("urn:partner.soap.sforce.com", "SforceService")).getPort(Soap.class);
    }

    public LoginResult login(String userName, String password, String securityToken) throws InvalidIdFault_Exception, LoginFault_Exception, UnknownHostException {
        try {
            WSBindingProvider wsBindingProvider = (WSBindingProvider) service;
            Map<String, Object> reqContext = wsBindingProvider.getRequestContext();
            String endpointAddress = "https://login.salesforce.com/services/Soap/u/26.0";

            reqContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointAddress);
            logger.log(Level.INFO, "Set login endpoint " + endpointAddress);
            loginResult = service.login(userName, password + securityToken);
            logger.log(Level.INFO, "Successful login " + userName);

            // set parameters for the session
            //    - use endpoint retrieved from login
            //    - set session id
            endpointAddress = loginResult.getServerUrl();
            logger.log(Level.INFO, "Set endpoint " + endpointAddress);
            reqContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointAddress);
            SessionHeader sessionHeader = new SessionHeader();
            sessionHeader.setSessionId(loginResult.getSessionId());
            wsBindingProvider.setOutboundHeaders(sessionHeader);

        } catch (UnexpectedErrorFault_Exception e) {
            throw new RuntimeException(e);
        }

        return loginResult;
    }

    public LoginResult getLoginResult() {
        return loginResult;
    }

    public List<String> describeGlobal() throws UnexpectedErrorFault_Exception {
        DescribeGlobalResult describeGlobalResult = service.describeGlobal();
        List<DescribeGlobalSObjectResult> describeGlobalSObjectResult = describeGlobalResult.getSobjects();
        List<String> describeGlobal = new ArrayList<String>();
        for (DescribeGlobalSObjectResult globalSObjectResult : describeGlobalSObjectResult) {
            describeGlobal.add(globalSObjectResult.getName());
        }

        return describeGlobal;
    }

    public DescribeSObjectResult describeSObject(String sObjectType) throws InvalidSObjectFault_Exception, UnexpectedErrorFault_Exception {
        return service.describeSObject(sObjectType);
    }

    public void logout() {
        try {
            if (loginResult != null) {
                service.logout();
            }
        } catch (UnexpectedErrorFault_Exception e) {
            logger.log(Level.WARNING, "Salesforce error logging out: " + e);
        }
    }
}
