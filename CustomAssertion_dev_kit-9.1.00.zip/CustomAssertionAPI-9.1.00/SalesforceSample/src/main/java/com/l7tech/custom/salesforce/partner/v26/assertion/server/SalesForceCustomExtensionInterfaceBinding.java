package com.l7tech.custom.salesforce.partner.v26.assertion.server;

import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceClient;
import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceConnection;
import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceCustomExtensionInterface;
import com.l7tech.custom.salesforce.partner.v26.assertion.util.SalesForceConnectionUtils;
import com.l7tech.policy.assertion.ext.password.SecurePasswordServices;
import com.l7tech.policy.assertion.ext.cei.CustomExtensionInterfaceBinding;
import com.l7tech.policy.assertion.ext.store.KeyValueStore;
import com.l7tech.policy.assertion.ext.store.KeyValueStoreServices;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Sever-side glue for the Salesforce custom extension interface implementation.
 */
public class SalesForceCustomExtensionInterfaceBinding extends CustomExtensionInterfaceBinding {
    private static final Logger logger = Logger.getLogger(SalesForceCustomExtensionInterfaceBinding.class.getName());

    public SalesForceCustomExtensionInterfaceBinding() {
        super(SalesForceCustomExtensionInterface.class, new SalesForceCustomExtensionInterface() {
            @Override
            public String[] describeGlobal(String connectionKey) throws Exception {
                logger.log(Level.INFO, "Invoking method on server side, this log entry will appear in the Gateway log.");

                KeyValueStoreServices keyValueStoreServices = getServiceFinder().lookupService(KeyValueStoreServices.class);
                KeyValueStore keyValueStore = keyValueStoreServices.getKeyValueStore();
                byte[] value = keyValueStore.get(connectionKey);
                if (value == null) {
                    throw new Exception("Cannot find SalesForce Connection with the specified key: " + connectionKey);
                }

                SalesForceConnection connection = SalesForceConnectionUtils.fromBytes(value);
                String username = connection.getUsername();
                String passwordId = connection.getPasswordId();
                String securityTokenId = connection.getSecurityTokenId();

                SecurePasswordServices securePasswordServices = getServiceFinder().lookupService(SecurePasswordServices.class);
                String password = securePasswordServices.decryptPassword(passwordId);
                String securityToken = securePasswordServices.decryptPassword(securityTokenId);

                SalesForceClient salesforceClient = new SalesForceClient();
                salesforceClient.login(username, password, securityToken);
                List<String> describeGlobalResults = salesforceClient.describeGlobal();
                return describeGlobalResults == null ? null : describeGlobalResults.toArray(new String[describeGlobalResults.size()]);
            }

            @Override
            public boolean testConnection(String userName, String passwordId, String securityTokenId) throws Exception {
                logger.log(Level.INFO, "Invoking method on server side, this log entry will appear in the Gateway log.");

                SecurePasswordServices securePasswordServices = getServiceFinder().lookupService(SecurePasswordServices.class);
                String password = securePasswordServices.decryptPassword(passwordId);
                String securityToken = securePasswordServices.decryptPassword(securityTokenId);

                SalesForceClient salesforceClient = new SalesForceClient();
                try {
                    salesforceClient.login(userName, password, securityToken);
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }
        });
    }
}
