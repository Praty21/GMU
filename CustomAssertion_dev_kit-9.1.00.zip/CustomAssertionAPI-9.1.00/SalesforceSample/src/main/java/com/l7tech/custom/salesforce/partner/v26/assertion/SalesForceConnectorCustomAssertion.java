package com.l7tech.custom.salesforce.partner.v26.assertion;

import com.l7tech.custom.salesforce.partner.v26.assertion.cache.SalesForceClientCacheManager;
import com.l7tech.custom.salesforce.partner.v26.assertion.util.Config;
import com.l7tech.custom.salesforce.partner.v26.assertion.util.SalesForceConnectionUtils;
import com.l7tech.policy.assertion.SetsVariables;
import com.l7tech.policy.assertion.UsesVariables;
import com.l7tech.policy.assertion.ext.*;
import com.l7tech.policy.assertion.ext.entity.CustomReferenceEntities;
import com.l7tech.policy.assertion.ext.entity.CustomReferenceEntitiesSupport;
import com.l7tech.policy.assertion.ext.password.SecurePasswordServices;
import com.l7tech.policy.assertion.ext.store.KeyValueStore;
import com.l7tech.policy.assertion.ext.store.KeyValueStoreChangeEventListener;
import com.l7tech.policy.assertion.ext.store.KeyValueStoreServices;
import com.l7tech.policy.assertion.ext.targetable.CustomMessageTargetable;
import com.l7tech.policy.assertion.ext.targetable.CustomMessageTargetableSupport;
import com.l7tech.policy.assertion.ext.validator.CustomPolicyValidator;
import com.l7tech.policy.variable.ContextVariablesUtils;
import com.l7tech.policy.variable.VariableMetadata;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * We use password entities hare, so make sure we tell the gateway accordingly, by implementing ReferenceEntities interface.<br/>
 * This is mandatory in order to migrate used entities correctly into a different gateway.
 * <p/>
 * <b>Serialization Note:</b> We cannot really deprecate local fields used by entities (i.e. connectionKey),
 * since they might have been serialized using a previous custom assertion version.
 * In the new custom assertion versions, best would be to keep them around only as a getters for readObject
 * and use entitiesSupport to actually store the values.
 */
public class SalesForceConnectorCustomAssertion implements CustomAssertion, SetsVariables, UsesVariables, CustomPolicyValidator, CustomMessageTargetable, CustomCredentialSource, CustomDynamicLoader, CustomReferenceEntities {
    // Backwards compatibility
    // Stream Unique Identifier (SUID) is a must in order to preserve class compatibility.
    // Otherwise, if omitted, for example when we add a new field the compiler will generate
    // a different SUID based on the fields order i.e. the fields are ordered with the primitive
    // types first sorted by field name, followed by the object fields sorted by field name.
    private static final long serialVersionUID = -6226341701628522253L;

    private static final String ASSERTION_NAME = "Salesforce.com Partner Connector POC";
    private static final String SALESFORCE_CONNECTION_ATTRIBUTE_NAME = "connectionKey"; // typically same as the field we want to replace

    // store all references here, try to avoid local variables when possible
    // TODO: rename to entitiesSupport
    private CustomReferenceEntitiesSupport entityReferenceSupport = new CustomReferenceEntitiesSupport();
    // We cannot really remove this field, it might have been serialized with a previous Custom Assertion version.
    // In the future versions, keep the field only as a getter for readObject and use entitiesSupport
    // to actually store the new value.
    @SuppressWarnings({"UnusedDeclaration"}) private String connectionKey;

    private String sObject;
    private String expandContextVariable;
    private String variablePrefix;

    // add new variables here and make sure they are read properly in readObject
    private CustomMessageTargetableSupport sourceTarget = new CustomMessageTargetableSupport("request", false);
    private CustomMessageTargetableSupport destinationTarget = new CustomMessageTargetableSupport("testOtherDestination", false);

    // determine if the assertion will act as a credential source or not
    boolean isCredentialSource = false;

    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();

        // initialize to default values if defaultReadObject doesn't serialize the objects
        // most likely because the object was serialized with prev version CustomAssertion version.

        if (sourceTarget == null) {
            // use the TARGET_REQUEST constant instead of typing request directly
            sourceTarget = new CustomMessageTargetableSupport(CustomMessageTargetableSupport.TARGET_REQUEST, false);
        }
        if (destinationTarget == null) {
            destinationTarget = new CustomMessageTargetableSupport("testOtherDestination", false);
        }

        // backwards compatibility for connectionKey, ensure older version can be de-serialized correctly
        // if entitiesSupport is missing from the stream, the stream contains a previous version of the custom assertion
        // in this case connectionKey will be set, therefore initialize entitiesSupport with it's value
        if (entityReferenceSupport == null) {
            entityReferenceSupport = new CustomReferenceEntitiesSupport();
            setConnectionKey(connectionKey);
        }
    }

    public String getsObject() {
        return sObject;
    }

    public void setsObject(String sObject) {
        this.sObject = sObject;
    }

    /**
     * @return the SalesForce connection key or {@code null} if there are no references.
     */
    public String getConnectionKey() {
        return entityReferenceSupport.getReference(SALESFORCE_CONNECTION_ATTRIBUTE_NAME);
    }

    /**
     * Sets the SalesForce connection key.<br/>
     * To remove any referenced SalesForce connection entities, pass {@code null}.  For example if {@code connectionKey}
     * is {@code null}, then the reference will be removed from entities support, otherwise it will be added/replaced.
     *
     * @param connectionKey    SalesForce connection key.
     */
    public void setConnectionKey(String connectionKey) {
        if (connectionKey != null) {
            entityReferenceSupport.setKeyValueStoreReference(
                    SALESFORCE_CONNECTION_ATTRIBUTE_NAME,
                    connectionKey,
                    SalesForceConnectionUtils.SALESFORCE_CONNECTION_NAME_PREFIX,
                    new SalesForceConnectionSerializer()
            );
        } else {
            entityReferenceSupport.removeReference(SALESFORCE_CONNECTION_ATTRIBUTE_NAME);
        }
    }

    public String getName() {
        return ASSERTION_NAME;
    }

    public String getExpandContextVariable() {
        return expandContextVariable;
    }

    public void setExpandContextVariable(String expandContextVariable) {
        this.expandContextVariable = expandContextVariable;
    }

    public String getVariablePrefix() {
        if (variablePrefix == null || variablePrefix.trim().isEmpty()) {
            // If not set, set to a default value.
            variablePrefix = "sfdc";
        }
        return variablePrefix;
    }

    public void setVariablePrefix(String variablePrefix) {
        this.variablePrefix = variablePrefix;
    }

    public String[] getVariablesUsed() {
        final String[] srcVariables = sourceTarget.getVariablesUsed();
        final String[] dstVariables = destinationTarget.getVariablesUsed();
        final String[] assertionFields = ContextVariablesUtils.getReferencedNames(expandContextVariable);

        final String[] retVariables = new String[srcVariables.length + dstVariables.length + assertionFields.length];
        System.arraycopy(srcVariables, 0, retVariables, 0, srcVariables.length);
        System.arraycopy(dstVariables, 0, retVariables, srcVariables.length, dstVariables.length);
        System.arraycopy(assertionFields, 0, retVariables, srcVariables.length + dstVariables.length, assertionFields.length);

        return retVariables;
    }

    public VariableMetadata[] getVariablesSet() {
        final VariableMetadata[] srcVariables = sourceTarget.getVariablesSet();
        final VariableMetadata[] dstVariables = destinationTarget.getVariablesSet();
        final VariableMetadata[] variables = new VariableMetadata[] {
                new VariableMetadata(this.getSessionIdVariable(), true, false, null, false),
                new VariableMetadata(this.getSessionUrlVariable(), true, false, null, false),
                new VariableMetadata(this.getVariablePrefix()+".expanded", true, false, null, false)
        };

        final VariableMetadata[] retVariables = new VariableMetadata[variables.length + srcVariables.length + dstVariables.length];
        System.arraycopy(srcVariables, 0, retVariables, 0, srcVariables.length);
        System.arraycopy(dstVariables, 0, retVariables, srcVariables.length, dstVariables.length);
        System.arraycopy(variables, 0, retVariables, srcVariables.length + dstVariables.length, variables.length);

        return retVariables;
    }

    public String getSessionIdVariable() {
        return getVariablePrefix() + "." + "sessionId";
    }

    public String getSessionUrlVariable() {
        return getVariablePrefix() + "." + "sessionUrl";
    }

    public String[] getVariableSuffixes () {
        return new String[] {"sessionId", "sessionUrl"};
    }

    @Override
    public List<String> getWarningMessages(Map<String, Object> consoleContext) {
        //noinspection Convert2Diamond
        LinkedList<String> result = new LinkedList<String>();

        if (this.getVariablePrefix() == null || this.getVariablePrefix().compareTo("sfdc") != 0) {
            result.add("#1. Variable Prefix is not equal to \"sfdc\"");
            result.add("#2. Variable Prefix is not equal to \"sfdc\"");
        }

        // Example usage of CustomExtensionInterfaceFinder
        //
        /*
        CustomExtensionInterfaceFinder extensionInterfaceFinder = (CustomExtensionInterfaceFinder) consoleContext.get(CustomExtensionInterfaceFinder.CONSOLE_CONTEXT_KEY);
        if (extensionInterfaceFinder != null) {
            try {
                SalesForceCustomExtensionInterface sfCustomExtInterface = extensionInterfaceFinder.getExtensionInterface(SalesForceCustomExtensionInterface.class);
                if (sfCustomExtInterface != null) {
                    String[] global = sfCustomExtInterface.describeGlobal(userName, "your_password", "your_security_token");
                }
            } catch (Exception e) {
                result.add(e.getMessage());
            }
        }
        */

        return result;
    }

    @Override
    public List<String> getErrorMessages(Map<String, Object> consoleContext) {
        //noinspection Convert2Diamond
        LinkedList<String> result = new LinkedList<String>();

        if (this.getVariablePrefix() == null || this.getVariablePrefix().compareTo("sfdc") != 0) {
            result.add("#1. Variable Prefix is not equal to \"sfdc\"");
            result.add("#2. Variable Prefix is not equal to \"sfdc\"");
        }

        // Example usage of CustomExtensionInterfaceFinder
        //
        /*
        CustomExtensionInterfaceFinder extensionInterfaceFinder = (CustomExtensionInterfaceFinder) consoleContext.get(CustomExtensionInterfaceFinder.CONSOLE_CONTEXT_KEY);
        if (extensionInterfaceFinder != null) {
            try {
                SalesForceCustomExtensionInterface sfCustomExtInterface = extensionInterfaceFinder.getExtensionInterface(SalesForceCustomExtensionInterface.class);
                if (sfCustomExtInterface != null) {
                    String[] global = sfCustomExtInterface.describeGlobal(userName, "your_password", "your_security_token");
                }
            } catch (Exception e) {
                result.add(e.getMessage());
            }
        }
        */

        return result;
    }

    @Override
    public String getTargetMessageVariable() {
        return sourceTarget.getTargetMessageVariable();
    }

    @Override
    public void setTargetMessageVariable(String targetMessageVariable) {
        sourceTarget.setTargetMessageVariable(targetMessageVariable);
    }

    @Override
    public String getTargetName() {
        return sourceTarget.getTargetName();
    }

    @Override
    public boolean isTargetModifiedByGateway() {
        return sourceTarget.isTargetModifiedByGateway();
    }

    public CustomMessageTargetableSupport getSourceTarget() {
        return sourceTarget;
    }

    public CustomMessageTargetableSupport getDestinationTarget() {
        return destinationTarget;
    }

    @Override
    public boolean isCredentialSource() {
        return this.isCredentialSource;
    }

    public void setCredentialSource(boolean isCredentialSource) {
        this.isCredentialSource = isCredentialSource;
    }

    @Override
    public void onLoad(final ServiceFinder serviceFinder) throws CustomLoaderException {
        // extract SecurePasswordServices and KeyValueStoreServices from ServiceFinder
        final SecurePasswordServices securePasswordServices = serviceFinder.lookupService(SecurePasswordServices.class);
        final KeyValueStoreServices keyValueStoreServices = serviceFinder.lookupService(KeyValueStoreServices.class);
        final KeyValueStore keyValueStore = keyValueStoreServices.getKeyValueStore();

        // create the salesforce cache manager singleton instance
        final SalesForceClientCacheManager salesForceClientCacheManager = SalesForceClientCacheManager.getInstance(Config.getInstance(), securePasswordServices);

        // register for key value store change event listener.
        KeyValueStoreChangeEventListener listener = keyValueStore.getListener(KeyValueStoreChangeEventListener.class);
        if (listener != null) {
            listener.add(SalesForceKeyValueStoreChangeEventCallback.getInstance(salesForceClientCacheManager));
        }
    }

    @Override
    public void onUnload(final ServiceFinder serviceFinder) {
        // extract SecurePasswordServices and KeyValueStoreServices from ServiceFinder
        final SecurePasswordServices securePasswordServices = serviceFinder.lookupService(SecurePasswordServices.class);
        final KeyValueStoreServices keyValueStoreServices = serviceFinder.lookupService(KeyValueStoreServices.class);
        final KeyValueStore keyValueStore = keyValueStoreServices.getKeyValueStore();

        // get the salesforce cache manager singleton instance
        final SalesForceClientCacheManager salesForceClientCacheManager = SalesForceClientCacheManager.getInstance(Config.getInstance(), securePasswordServices);
        // shutdown cache manager
        salesForceClientCacheManager.doShutdown();

        // unregister for key value store change event listener.
        KeyValueStoreChangeEventListener listener = keyValueStore.getListener(KeyValueStoreChangeEventListener.class);
        if (listener != null) {
            listener.remove(SalesForceKeyValueStoreChangeEventCallback.getInstance(salesForceClientCacheManager));
        }
    }

    /**
     * Always return a singleton, never return new instances.
     */
    @Override
    public CustomReferenceEntitiesSupport getReferenceEntitiesSupport() {
        // always return our singleton, never return new instances
        return entityReferenceSupport;
    }
}
