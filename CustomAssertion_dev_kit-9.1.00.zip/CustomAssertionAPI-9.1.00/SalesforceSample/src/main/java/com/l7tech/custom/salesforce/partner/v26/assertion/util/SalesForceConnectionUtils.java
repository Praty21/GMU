package com.l7tech.custom.salesforce.partner.v26.assertion.util;

import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceConnection;
import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceConnectionSerializer;

/**
 * Utility class for converting {@link SalesForceConnection} to bytes and vise versa.
 */
public class SalesForceConnectionUtils {

    public static final String SALESFORCE_CONNECTION_NAME_PREFIX = SalesForceConnection.class.getName()+".";

    public static String convertConnectionUuidToKey(final String uuid) {
        return SALESFORCE_CONNECTION_NAME_PREFIX + uuid;
    }

    public static byte[] toBytes (final SalesForceConnection connection) {
        return new SalesForceConnectionSerializer().serialize(connection);
    }

    public static SalesForceConnection fromBytes (final byte[] value) {
        return new SalesForceConnectionSerializer().deserialize(value);
    }
}