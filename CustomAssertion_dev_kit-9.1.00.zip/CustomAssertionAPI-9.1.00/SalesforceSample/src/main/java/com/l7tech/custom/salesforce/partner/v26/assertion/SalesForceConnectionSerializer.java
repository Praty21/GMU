package com.l7tech.custom.salesforce.partner.v26.assertion;

import com.l7tech.policy.assertion.ext.entity.CustomEntitySerializer;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * {@link SalesForceConnection} Serializer class.
 */
public class SalesForceConnectionSerializer implements CustomEntitySerializer<SalesForceConnection> {
    private static final Logger logger = Logger.getLogger(SalesForceConnectionSerializer.class.getName());

    @Override
    public byte[] serialize(final SalesForceConnection entity) {
        if (entity == null) {
            return null;
        }

        final Properties prop = entity.toProperties();
        final ByteArrayOutputStream out = new ByteArrayOutputStream(1024);
        try {
            prop.storeToXML(out, "Sample Salesforce Connection");
            return out.toByteArray();
        } catch (IOException e) {
            logger.log(Level.WARNING, "Error while writing Salesforce connection.", e);
            return null;
        } finally {
            try { out.close(); } catch (IOException ignore) { /* Close quietly. */ }
        }
    }

    @Override
    public SalesForceConnection deserialize(final byte[] bytes) {
        if (bytes == null) {
            return null;
        }

        final Properties prop = new Properties();
        final ByteArrayInputStream in = new ByteArrayInputStream(bytes);
        try {
            prop.loadFromXML(in);
            return new SalesForceConnection(prop);
        } catch (IOException e) {
            logger.log(Level.WARNING, "Error while reading Salesforce connection.", e);
            return null;
        } finally {
            try { in.close(); } catch (IOException ignore) { /* Close quietly. */ }
        }
    }
}
