package com.l7tech.custom.salesforce.partner.v26.assertion.console;

import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Map;

/**
 * Simple dialog having the SalesForceConnectionPropertiesPanel and an Ok and Cancel button.
 */
public class SalesForceConnectionPropertiesDialog extends JDialog {
    private JButton okButton;
    private JButton cancelButton;
    private JPanel propertiesPanelHolder;
    private JPanel mainPanel;
    private SalesForceConnectionPropertiesPanel connectionPropertiesPanel;

    private boolean confirmed = false;

    public SalesForceConnectionPropertiesDialog(JDialog owner, Map consoleContext, SalesForceConnection connection) {
        super(owner, "Salesforce Connection Properties", true);

        this.connectionPropertiesPanel = new SalesForceConnectionPropertiesPanel();
        connectionPropertiesPanel.setConsoleContextUsed(consoleContext);
        connectionPropertiesPanel.initialize(connection);

        this.initialize();
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public void setConfirmed(boolean confirmed) {
        this.confirmed = confirmed;
    }

    private void initialize() {
        propertiesPanelHolder.setLayout(new BorderLayout());
        propertiesPanelHolder.add(connectionPropertiesPanel, BorderLayout.CENTER);
        propertiesPanelHolder.setBorder(BorderFactory.createEmptyBorder());

        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onOk();
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        mainPanel.registerKeyboardAction(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        onCancel();
                    }
                },
                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
                JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT
        );

        setContentPane(mainPanel);
        getRootPane().setDefaultButton(okButton);
        pack();
    }

    private void onOk() {
        if (null != connectionPropertiesPanel.validateEntity()) {
            confirmed = true;
            dispose();
        }
    }

    private void onCancel() {
        dispose();
    }
}