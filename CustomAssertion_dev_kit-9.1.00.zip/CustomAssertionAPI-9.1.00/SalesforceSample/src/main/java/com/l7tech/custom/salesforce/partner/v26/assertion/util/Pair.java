package com.l7tech.custom.salesforce.partner.v26.assertion.util;

/**
 * A utility class that holds a two-item tuple.
 */
public class Pair<L,R> {

    public final L left;
    public final R right;

    public static <L,R> Pair<L,R> pair(final L left, final R right) {
        return new Pair<L,R>(left, right);
    }

    private Pair(L left, R right) {
        this.left = left;
        this.right = right;
    }

    @SuppressWarnings("RedundantIfStatement")
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        final Pair pair = (Pair) obj;

        if (left != null ? !left.equals(pair.left) : pair.left != null) return false;
        if (right != null ? !right.equals(pair.right) : pair.right != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result;
        result = (left != null ? left.hashCode() : 0);
        result = 31 * result + (right != null ? right.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return String.format("(%s,%s)", left, right);
    }
}
