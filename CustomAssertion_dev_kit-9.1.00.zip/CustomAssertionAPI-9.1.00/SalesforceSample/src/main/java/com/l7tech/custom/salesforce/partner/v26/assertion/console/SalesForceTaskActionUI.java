package com.l7tech.custom.salesforce.partner.v26.assertion.console;

import com.l7tech.policy.assertion.ext.action.CustomTaskActionUI;
import com.l7tech.policy.assertion.ext.cei.UsesConsoleContext;

import javax.swing.*;
import java.awt.*;
import java.io.Serializable;
import java.util.Map;

public class SalesForceTaskActionUI implements CustomTaskActionUI, UsesConsoleContext, Serializable {

    private Map consoleContext;

    @Override
    public String getName() {
        return "Manage Sample Salesforce Connections";
    }

    @Override
    public String getDescription() {
        return "Create, edit, and remove configuration for Salesforce connections.";
    }

    @Override
    public ImageIcon getIcon() {
        return new ImageIcon(getClass().getClassLoader().getResource("icon.salesforce.16.png"));
    }

    @Override
    public JDialog getDialog(Frame owner) {
        return new ManageSalesForceConnectionsDialog(owner, consoleContext);
    }

    @Override
    public void setConsoleContextUsed(Map consoleContext) {
        this.consoleContext = consoleContext;
    }
}