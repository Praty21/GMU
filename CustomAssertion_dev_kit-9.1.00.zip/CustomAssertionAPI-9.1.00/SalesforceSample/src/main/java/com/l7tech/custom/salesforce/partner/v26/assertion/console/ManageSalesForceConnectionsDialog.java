package com.l7tech.custom.salesforce.partner.v26.assertion.console;

import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceConnection;
import com.l7tech.custom.salesforce.partner.v26.assertion.util.Pair;
import com.l7tech.custom.salesforce.partner.v26.assertion.util.SalesForceConnectionUtils;
import com.l7tech.policy.assertion.ext.store.KeyValueStore;
import com.l7tech.policy.assertion.ext.store.KeyValueStoreException;
import com.l7tech.policy.assertion.ext.store.KeyValueStoreServices;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Displays the settings of a Salesforce Connection.
 */
public class ManageSalesForceConnectionsDialog extends JDialog {
    private static final Logger logger = Logger.getLogger(ManageSalesForceConnectionsDialog.class.getName());

    private JPanel mainPanel;
    private JTable connectionTable;
    private JButton addButton;
    private JButton editButton;
    private JButton removeButton;
    private JButton closeButton;

    private Map consoleContext;
    private SalesForceConnectionTableModel connectionTableModel;

    /**
     * Represents JTable model having a pair of SalesForce Connection and connection key as an element.<br/>
     * We need to know which key belongs to which SalesForce Connection.
     */
    private static class SalesForceConnectionTableModel extends AbstractTableModel {
        /**
         * Represents a fallback value when the SalesForce connection doesn't have a mandatory name in the bytes.
         */
        private static final String UNRESOLVED_CONNECTION = "<UNRESOLVED>";

        /**
         * Default value for column out-of-index i.e. out of enum ordinal.
         */
        private static final String UNRESOLVED_COLUMN = "<UNKNOWN COLUMN>";

        /**
         * Tag values depending whether the SalesForce connection is enabled or not
         */
        private static final String YES = "Yes";
        private static final String NO = "No";

        /**
         * Column definition.
         * Column order is defined here by enum ordinal.
         */
        private static enum Columns {
            ConnectionName("Connection Name"),
            UserName("User Name"),
            Description("Description"),
            Enabled("Enabled");

            private final String name;
            private Columns(final String name) {
                this.name = name;
            }
        }

        /**
         * Internal {@code SalesForceConnection} model-view, represents an array of SalesForce connection and key pairs.<br/>
         * This way we'll know exactly which key corresponds to which SalesForce connection.
         */
        private final List<Pair<String, SalesForceConnection>> connections = new ArrayList<Pair<String, SalesForceConnection>>();

        /**
         * The {@code KeyValueStore} to access SalesForce connections.
         */
        private final KeyValueStore keyValueStore;

        /**
         * Default constructor.
         * @param keyValueStore    key-value-store for accessing SalesForce connections
         */
        private SalesForceConnectionTableModel(final KeyValueStore keyValueStore) {
            if (keyValueStore == null) {
                throw new IllegalArgumentException("keyValueStore cannot be null");
            }
            this.keyValueStore = keyValueStore;
        }

        /**
         * Rebuild the internal model-view.<br/>
         * Call this method after adding or new or removing existing SalesForce connection.
         */
        public void rebuild() {
            final int oldRowCount = connections.size();

            // clear existing connections
            connections.clear();

            // if necessary (i.e. not already empty) notify that all rows have been removed
            if (oldRowCount > 0) {
                fireTableRowsDeleted(0, oldRowCount - 1);
            }

            final Map<String, byte[]> map = keyValueStore.findAllWithKeyPrefix(SalesForceConnectionUtils.SALESFORCE_CONNECTION_NAME_PREFIX);
            for (Map.Entry<String, byte[]> entry : map.entrySet()) {
                SalesForceConnection connection = SalesForceConnectionUtils.fromBytes(entry.getValue());
                if (connection != null) {
                    connections.add(Pair.pair(entry.getKey(), SalesForceConnectionUtils.fromBytes(entry.getValue())));
                } else {
                    logger.log(Level.FINE, "Ignoring null connection retrieved from Key Value Store: " + entry.getKey());
                }
            }

            // if necessary (i.e. empty now after rebuild) notify that new rows have been added
            final int rowCount = connections.size();
            if (rowCount > 0) {
                fireTableRowsInserted(0, rowCount - 1);
            }
        }

        /**
         * Utility function for accessing SalesForce connection and key.<br/>
         * When sorting is enabled, then convert the {@code rowIndex} to {@code modelIndex} by using
         * {@link JTable#convertRowIndexToModel(int)}<br/>
         * The function will try to detect if the {@code keyValueStore} has been modified from another thread,
         * and will automatically rebuild it's model view. However if rebuild is unsuccessful then {@code null} ifs returned.
         *
         * @param modelIndex    the model index
         * @return a pair of SalesForce connection and key, or null if the model-view cannot be rebuild or
         * an error happens while accessing the key-value-store or the modelIndex is out-of-bounds.
         */
        public Pair<String, SalesForceConnection> getConnectionAt(final int modelIndex) {
            String connectionKey = null;
            try {
                connectionKey = connections.get(modelIndex).left;

                // get the connection directly from key-value-store in case some other process updated this entity
                SalesForceConnection connection = SalesForceConnectionUtils.fromBytes(keyValueStore.get(connectionKey));
                if (connection == null) {
                    // we no longer have entity associated with this key
                    // rebuild, since some other process has modified the key-value-store
                    rebuild();

                    // retry with the same row-index
                    connectionKey = connections.get(modelIndex).left;
                    connection = SalesForceConnectionUtils.fromBytes(keyValueStore.get(connectionKey));
                    if (connection == null) {
                        // if still nothing return null
                        return null;
                    }
                }

                return Pair.pair(connectionKey, connection);
            } catch (IndexOutOfBoundsException ignore) {
                /* ignore */
            } catch (KeyValueStoreException ex) {
                logger.log(Level.WARNING, "Error while extracting key-value-store with key: " + connectionKey, ex);
            }

            return null;
        }

        /**
         * @return the number of rows in the model.
         */
        @Override
        public int getRowCount() {
            return connections.size();
        }

        /**
         * @return the number of columns in the model.
         */
        @Override
        public int getColumnCount() {
            return Columns.values().length;
        }

        /**
         * Returns the column name specified by the {@code columnIndex}.<br/>
         * The column order is defined by the enum ordinal value.
         *
         * @param columnIndex    the column being queried.
         */
        @Override
        public String getColumnName(final int columnIndex) {
            if (columnIndex == Columns.ConnectionName.ordinal()) {
                return Columns.ConnectionName.name;
            } else if (columnIndex == Columns.UserName.ordinal()) {
                return Columns.UserName.name;
            } else if (columnIndex == Columns.Description.ordinal()) {
                return Columns.Description.name;
            } else if (columnIndex == Columns.Enabled.ordinal()) {
                return Columns.Enabled.name;
            } else {
                logger.warning("columnIndex = " + String.valueOf(columnIndex) + ", is out of bounds. Must be between 0 and " +
                        String.valueOf(getColumnCount() - 1));
            }

            return UNRESOLVED_COLUMN;
        }

        /**
         * We use strings therefore return the {@code String.class}.
         */
        @Override
        public Class<?> getColumnClass(int columnIndex) {
            return String.class;
        }

        /**
         * Returns the value for the cell at {@code columnIndex} and {@code rowIndex}.
         *
         * @param rowIndex       the row whose value is to be queried
         * @param columnIndex    the column whose value is to be queried
         * @return a {@code String} containing the requested value at {@code columnIndex} and {@code rowIndex},
         * or {@code null} when either {@code columnIndex} or {@code rowIndex} is out-of-bound.
         */
        @Override
        public Object getValueAt(final int rowIndex, final int columnIndex) {
            try {
                final Pair<String, SalesForceConnection> connectionPair = connections.get(rowIndex);
                if (columnIndex == Columns.ConnectionName.ordinal()) {
                    final String connectionName = connectionPair.right.getConnectionName();
                    return connectionName != null ? connectionName : UNRESOLVED_CONNECTION;
                } else if (columnIndex == Columns.UserName.ordinal()) {
                    return connectionPair.right.getUsername();
                } else if (columnIndex == Columns.Description.ordinal()) {
                    return connectionPair.right.getDescription();
                } else if (columnIndex == Columns.Enabled.ordinal()) {
                    return connectionPair.right.isEnabled() ? YES : NO;
                } else {
                    logger.warning("columnIndex = " + String.valueOf(columnIndex) + ", is out of bounds. Must be between 0 and " +
                            String.valueOf(getColumnCount() - 1));
                }
            } catch (IndexOutOfBoundsException e) {
                logger.warning("rowIndex = " + String.valueOf(rowIndex) + ", is out of bounds. Must be between 0 and " +
                        String.valueOf(connections.size() == 0 ? 0 : connections.size() - 1));
            }
            return null;
        }

        /**
         * Cells are not editable here.
         */
        @Override
        public boolean isCellEditable(final int rowIndex, final int columnIndex) {
            return false;
        }
    }

    public ManageSalesForceConnectionsDialog(Frame owner, Map consoleContext) {
        super(owner, "Manage Salesforce Connections", true);

        this.consoleContext = consoleContext;

        this.initialize();
        this.reloadConnectionTable();
        this.enableDisableComponents();
    }

    private void initialize() {

        // set our custom table model
        connectionTable.setModel(connectionTableModel = new SalesForceConnectionTableModel(getKeyValueStore()));
        connectionTable.getTableHeader().setReorderingAllowed(false);
        connectionTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Row Sorter
        //
        final TableRowSorter<SalesForceConnectionTableModel> connectionTableRowSorter = new TableRowSorter<SalesForceConnectionTableModel>(connectionTableModel);
        final List<RowSorter.SortKey> sortKeys = new ArrayList<RowSorter.SortKey>(1);
        sortKeys.add(new RowSorter.SortKey(0, SortOrder.ASCENDING));
        connectionTableRowSorter.setSortKeys(sortKeys);
        connectionTableRowSorter.setComparator(0, String.CASE_INSENSITIVE_ORDER);
        connectionTable.setRowSorter(connectionTableRowSorter);
        connectionTableRowSorter.sort();

        connectionTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                enableDisableComponents();
            }
        });

        // Double-click listener.
        //
        connectionTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    onEdit();
                }
            }
        });

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                onAdd();
            }
        });

        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                onEdit();
            }
        });

        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                onRemove();
            }
        });

        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                onClose();
            }
        });

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onClose();
            }
        });

        mainPanel.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onClose();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        setContentPane(mainPanel);
        getRootPane().setDefaultButton(closeButton);
    }

    private void onAdd() {
        updateOrSave(null);
    }

    private void onEdit() {
        // get the SalesForce connection of the selected row
        // since sorting is enabled we must convert the row index into model index,
        // since getConnectionAt expects model index
        final Pair<String, SalesForceConnection> connectionPair =
                connectionTableModel.getConnectionAt(
                        connectionTable.convertRowIndexToModel(
                                connectionTable.getSelectedRow()
                        )
                );
        if (connectionPair == null) return;

        updateOrSave(connectionPair);
    }

    /**
     * This helper method can do create/edit connection, depending on the given parameter as below.<br/>
     * Case 1: connectionPair == null: Create<br/>
     * Case 3: connectionPair != null: Edit
     * 
     * @param connectionPair: a pair containing the connection key and entity object.
     */
    private void updateOrSave(final Pair<String, SalesForceConnection> connectionPair) {
        // update or save flag
        final boolean isUpdate = connectionPair != null;
        // get the key-value-store
        final KeyValueStore keyValueStore = getKeyValueStore();
        // get the SalesForce connection from the connectionPair or create one is not-update
        final SalesForceConnection connection = isUpdate ? connectionPair.right : new SalesForceConnection();
        // if update get the original connection name, we'll need it to determine whether it was changed or not
        final String originalConnectionName = isUpdate ? connectionPair.right.getConnectionName() : null;
        // create the properties panel
        final SalesForceConnectionPropertiesDialog dialog = new SalesForceConnectionPropertiesDialog(
                ManageSalesForceConnectionsDialog.this, 
                consoleContext,
                connection
        );

        boolean done = false;
        while (! done) {
            // Refresh existingConnNames list, just in case someone else updates the connection db table at the same time.
            final Map<String, byte[]> existingConnections = keyValueStore.findAllWithKeyPrefix(SalesForceConnectionUtils.SALESFORCE_CONNECTION_NAME_PREFIX);
            final java.util.List<String> existingConnNames = new ArrayList<String>();
            for (String connectionKey: existingConnections.keySet()) {
                SalesForceConnection conn = SalesForceConnectionUtils.fromBytes(keyValueStore.get(connectionKey));
                if (conn != null) {
                    existingConnNames.add(conn.getConnectionName());
                }
            }

            dialog.setLocationRelativeTo(this);
            dialog.setVisible(true);

            if (dialog.isConfirmed()) {
                // The object "connection" has been updated after the SalesforceOperationServiceConnectionPropertiesDialog is confirmed.
                final String newConnName = connection.getConnectionName();

                // if save then the newConnName must be unique
                // if update and the connection didn't have original name, then only check if the newConnName is unique
                // if update and the connection did had original name, then check whether the newConnName is unique only if its different then the original
                if ( (!isUpdate && existingConnNames.contains(newConnName)) ||
                        (isUpdate && (originalConnectionName != null && !originalConnectionName.equals(newConnName)) && existingConnNames.contains(newConnName)) )
                {
                    JOptionPane.showMessageDialog(
                            dialog,
                            "Unable to save connection: The connection '" + newConnName + "' already exists.",
                            "Saving Connection Error", JOptionPane.WARNING_MESSAGE
                    );
                    dialog.setConfirmed(false);
                    continue;
                }
                try {
                    if (isUpdate) {
                        // update
                        keyValueStore.update(connectionPair.left, SalesForceConnectionUtils.toBytes(connection));
                    } else {
                        // save
                        keyValueStore.save(
                                SalesForceConnectionUtils.convertConnectionUuidToKey(
                                        UUID.randomUUID().toString()
                                ),
                                SalesForceConnectionUtils.toBytes(connection)
                        );
                    }
                } catch (KeyValueStoreException e) {
                    JOptionPane.showMessageDialog(dialog, e.getMessage(), "Saving Connection Error", JOptionPane.WARNING_MESSAGE);
                    dialog.setConfirmed(false);
                    continue;
                }
                done = true;
                // if no errors, rebuild the model-view
                this.reloadConnectionTable();
            } else {
                done = true;
            }
        }
    }

    private void onRemove() {
        // get the SalesForce connection of the selected row
        // since sorting is enabled we must convert the row index into model index,
        // since getConnectionAt expects model index
        final Pair<String, SalesForceConnection> connectionPair =
                connectionTableModel.getConnectionAt(
                        connectionTable.convertRowIndexToModel(
                                connectionTable.getSelectedRow()
                        )
                );
        if (connectionPair == null) return;

        final KeyValueStore keyValueStore = getKeyValueStore();
        keyValueStore.delete(connectionPair.left);

        this.reloadConnectionTable();
    }

    private void onClose() {
        dispose();
    }

    private void reloadConnectionTable() {
        // rebuild our model-view
        connectionTableModel.rebuild();
    }

    private void enableDisableComponents() {
        boolean enabled = connectionTable.getSelectedRow() != -1;
        editButton.setEnabled(enabled);
        removeButton.setEnabled(enabled);
    }

    private KeyValueStore getKeyValueStore() {
        KeyValueStoreServices keyValueStoreServices = (KeyValueStoreServices)consoleContext.get(KeyValueStoreServices.CONSOLE_CONTEXT_KEY);
        return keyValueStoreServices.getKeyValueStore();
    }
}