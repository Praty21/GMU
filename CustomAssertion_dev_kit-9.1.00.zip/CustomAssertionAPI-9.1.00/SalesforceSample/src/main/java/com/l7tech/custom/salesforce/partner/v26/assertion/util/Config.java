package com.l7tech.custom.salesforce.partner.v26.assertion.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Helper class that loads the required configuration (run-time configuration only, design-time UI can't access properties file).
 */
public class Config {
    // public final static String SALESFORCE_GATEWAY_BROKER_SERVICE_PORT = "salesforce.gateway.broker.service.port";
    public final static String SALESFORCE_CONNECTION_CACHE_CLEAN_INTERVAL_PROPERTY = "salesforce.io.connection.cache.clean.interval";
    public final static String SALESFORCE_CONNECTION_CACHE_MAX_AGE_PROPERTY = "salesforce.io.connection.cache.max.age";
    public final static String SALESFORCE_CONNECTION_CACHE_MAX_IDLE_PROPERTY = "salesforce.io.connection.cache.max.idle.time";
    public final static String SALESFORCE_CONNECTION_CACHE_MAX_SIZE_PROPERTY = "salesforce.io.connection.cache.size";
    public final static String SALESFORCE_DEV_DEBUG_ALWAYS_RETURN_FAILED_PROPERTY = "salesforce.dev.debug.always.return.failed";

    private final static String CONFIG_FILE_NAME = "salesforce_connector.properties";
    // private final static String WSDL_FILE_NAME = "salesforce-partner-v26.wsdl";

    private static final Logger logger = Logger.getLogger(Config.class.getName());
    private static Config instance = null;
    private Properties properties = null;

    private Config() {
        String ssgConfigPath = System.getProperty("ssg.config.dir", "/opt/SecureSpan/Gateway/node/default/etc/conf");
        String propertiesFile = ssgConfigPath + "/" + Config.CONFIG_FILE_NAME;
        try {
            properties = Config.retrieveProperties(propertiesFile);
        } catch (Throwable t) {
            logger.log(Level.WARNING, "Continue after error: ", t.getMessage());
        }
    }

    public static Config getInstance() {
        if (instance == null) {
            instance = new Config();
        }
        return instance;
    }

    public String getProperty( final String propertyName ) {
        return getProperty( propertyName, null );
    }

    public String getProperty( final String propertyName, final String defaultValue ) {
        String propertyValue = null;

        final Properties properties = this.properties;
        if (properties != null) {
            propertyValue = (String) properties.get(propertyName);
        }

        if ( propertyValue == null ) {
            propertyValue = defaultValue;
        }

        return propertyValue;
    }

    /**
     * Convenience method to get a property as an int.
     *
     * @param propertyName the name of the property to get
     * @param defaultValue the default value to return if the property is not set or if it is not a valid int
     * @return the requested property value, or the default if it is not set or is invalid
     */
    public int getIntegerProperty( final String propertyName, final int defaultValue ) {
        String val = getProperty(propertyName);
        if (val == null)
            return defaultValue;
        try {
            return Integer.parseInt( val );
        } catch (NumberFormatException nfe) {
            logger.log(Level.WARNING, "Invalid integer property value for " + propertyName + ": " + val);
            return defaultValue;
        }
    }

    /**
     * Convenience method to get a property as a time unit.
     *
     * @param propertyName the name of the property to get
     * @param defaultValue the default value to return if the property is not set or if it is not a valid time unit
     * @return the requested property value, or the default if it is not set or is invalid
     */
    public long getTimeUnitProperty(final String propertyName, final long defaultValue) {
        return TimeUnit.parse(getProperty(propertyName, Long.toString(defaultValue)), TimeUnit.MILLIS);
    }

    public boolean getBooleanProperty( final String propertyName ) {
        return Boolean.parseBoolean(getProperty(propertyName));
    }

    private static Properties retrieveProperties(String propertiesFile) {
        Properties props = new Properties();
        if (propertiesFile == null) {
            String msg = "Couldn't load properties";
//            logger.severe(msg);
            throw new RuntimeException(msg);
        }

        FileInputStream propStream = null;
        try {
            propStream = null;

            File file = new File(propertiesFile);
            if (file.exists()) {
                propStream = new FileInputStream(file);
                props.load(propStream);
                logger.info("Loading properties from " + propertiesFile);
                return props;
            } else {
                logger.warning(propertiesFile + " not found");
                return null;
            }

        } catch (IOException ioe) {
            logger.severe("Couldn't load " + propertiesFile);
            throw new RuntimeException("Couldn't load " + propertiesFile);
        } finally {
            if (propStream != null) {
                try {
                    propStream.close();
                } catch (IOException e) {
                    logger.log(Level.WARNING, "io error", e);
                }
            }
        }
    }
}
