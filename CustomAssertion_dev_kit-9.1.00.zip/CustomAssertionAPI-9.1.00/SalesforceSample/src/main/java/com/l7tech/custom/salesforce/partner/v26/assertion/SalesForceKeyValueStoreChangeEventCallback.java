package com.l7tech.custom.salesforce.partner.v26.assertion;

import com.l7tech.custom.salesforce.partner.v26.assertion.cache.SalesForceClientCacheManager;
import com.l7tech.custom.salesforce.partner.v26.assertion.util.SalesForceConnectionUtils;
import com.l7tech.policy.assertion.ext.store.KeyValueStoreChangeEventListener;

import java.util.List;

/**
 */
public class SalesForceKeyValueStoreChangeEventCallback implements KeyValueStoreChangeEventListener.Callback {
    private static SalesForceKeyValueStoreChangeEventCallback instance = null;
    private final SalesForceClientCacheManager salesForceClientCacheManager;

    public static SalesForceKeyValueStoreChangeEventCallback getInstance(SalesForceClientCacheManager salesForceClientCacheManager) {
        if (instance == null) {
            instance = new SalesForceKeyValueStoreChangeEventCallback(salesForceClientCacheManager);
        }
        return instance;
    }

    private SalesForceKeyValueStoreChangeEventCallback(SalesForceClientCacheManager salesForceClientCacheManager) {
        this.salesForceClientCacheManager = salesForceClientCacheManager;
    }

    @Override
    public String getKeyPrefix() {
        return SalesForceConnectionUtils.SALESFORCE_CONNECTION_NAME_PREFIX;
    }

    @Override
    public void onEvent(List<KeyValueStoreChangeEventListener.Event> events) {
        for (KeyValueStoreChangeEventListener.Event event : events) {
            // Ignore Create operation, since it won't be in the cache.
            if (KeyValueStoreChangeEventListener.Operation.UPDATE == event.getOperation() ||
                KeyValueStoreChangeEventListener.Operation.DELETE == event.getOperation()) {
                salesForceClientCacheManager.invalidate(event.getKey());
            }
        }
    }
}