package com.l7tech.custom.salesforce.partner.v26.assertion;

import com.l7tech.custom.salesforce.partner.v26.assertion.console.MissingSalesForceConnectionDetailPanel;
import com.l7tech.custom.salesforce.partner.v26.assertion.console.SalesForceConnectionPropertiesPanel;
import com.l7tech.policy.assertion.ext.entity.CustomReferenceEntitiesSupport;
import com.l7tech.policy.assertion.ext.entity.CustomEntityType;
import com.l7tech.policy.assertion.ext.entity.CustomEntityDescriptor;
import com.l7tech.policy.assertion.ext.entity.CustomReferenceEntities;

import javax.swing.*;
import java.util.Properties;

/**
 * We use password entities here, so make sure we tell the gateway accordingly, by implementing ReferenceEntities interface.<br/>
 * This is mandatory in order to migrate used entities correctly into a different gateway.
 */
public class SalesForceConnection implements CustomReferenceEntities, CustomEntityDescriptor {
    private static final String ENTITY_TYPE_NAME = "SalesForce Connection";

    private static final String PROPERTY_NAME_CONNECTION_NAME= "connectionName";
    private static final String PROPERTY_NAME_DESCRIPTION= "description";
    private static final String PROPERTY_NAME_USERNAME = "username";
    private static final String PROPERTY_NAME_PASSWORD_ID = "passwordId";
    private static final String PROPERTY_NAME_SECURITY_TOKEN_ID = "securityTokenId";
    private static final String PROPERTY_NAME_ENABLED = "enabled";

    private static final String PASSWORD_ID_ATTRIBUTE_NAME = "password-id";
    private static final String ENTITY_REFERENCE_SECURE_TOKEN_ID_TAG = "secure-token-id";

    // store all references here, try to avoid local variables when possible
    private CustomReferenceEntitiesSupport entitiesSupport = new CustomReferenceEntitiesSupport();
    // We can deprecate these field, since SalesForceConnection class is not really serializable.
    //private String passwordId = null;
    //private String securityTokenId = null;

    private String connectionName;
    private String description;
    private String username;
    private boolean enabled = true;

    public SalesForceConnection () {
    }

    public SalesForceConnection (Properties properties) {
        this.setConnectionName(properties.getProperty(PROPERTY_NAME_CONNECTION_NAME));
        this.setDescription(properties.getProperty(PROPERTY_NAME_DESCRIPTION));
        this.setUsername(properties.getProperty(PROPERTY_NAME_USERNAME));
        this.setPasswordId(properties.getProperty(PROPERTY_NAME_PASSWORD_ID));
        this.setSecurityTokenId(properties.getProperty(PROPERTY_NAME_SECURITY_TOKEN_ID));
        this.setEnabled(Boolean.parseBoolean(properties.getProperty(PROPERTY_NAME_ENABLED)));
    }

    public Properties toProperties() {
        Properties properties = new Properties();
        properties.setProperty(PROPERTY_NAME_CONNECTION_NAME, this.getConnectionName());
        properties.setProperty(PROPERTY_NAME_DESCRIPTION, this.getDescription());
        properties.setProperty(PROPERTY_NAME_USERNAME, this.getUsername());
        properties.setProperty(PROPERTY_NAME_PASSWORD_ID, this.getPasswordId());
        properties.setProperty(PROPERTY_NAME_SECURITY_TOKEN_ID, this.getSecurityTokenId());
        properties.setProperty(PROPERTY_NAME_ENABLED, Boolean.toString(this.isEnabled()));
        
        return properties;
    }

    public String getConnectionName() {
        return connectionName;
    }

    public void setConnectionName(String connectionName) {
        this.connectionName = connectionName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordId() {
        return entitiesSupport.getReference(PASSWORD_ID_ATTRIBUTE_NAME);
    }

    public void setPasswordId(String passwordId) {
        entitiesSupport.setReference(PASSWORD_ID_ATTRIBUTE_NAME, passwordId, CustomEntityType.SecurePassword);
    }

    public String getSecurityTokenId() {
        return entitiesSupport.getReference(ENTITY_REFERENCE_SECURE_TOKEN_ID_TAG);
    }

    public void setSecurityTokenId(String securityTokenId) {
        entitiesSupport.setReference(ENTITY_REFERENCE_SECURE_TOKEN_ID_TAG, securityTokenId, CustomEntityType.SecurePassword);
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean isEnabled) {
        this.enabled = isEnabled;
    }

    @Override
    public CustomReferenceEntitiesSupport getReferenceEntitiesSupport() {
        return entitiesSupport;
    }

    @Override
    public <R> R getProperty(String name, Class<R> rClass) {
        if (name == null) {
            throw new IllegalArgumentException("name cannot be null");
        }
        if (rClass == null) {
            throw new IllegalArgumentException("rClass cannot be null");
        }

        if (name.equals(NAME) && rClass.equals(String.class)) {
            return rClass.cast(getConnectionName());
        } else if (name.equals(TYPE) && rClass.equals(String.class)) {
            return rClass.cast(ENTITY_TYPE_NAME);
        } else if (name.equals(DESCRIPTION) && rClass.equals(String.class)) {
            return rClass.cast(getDescription());
        } else if (name.equals(SUMMARY) && rClass.equals(String.class)) {
            final String connectionName = getConnectionName();
            if (connectionName == null || connectionName.trim().isEmpty()) {
                return rClass.cast("<Unresolved " + ENTITY_TYPE_NAME + ">");
            } else {
                return rClass.cast(getConnectionName() + " [" + getDescription() + "]");
            }
        } 

        return null;
    }

    @Override
    public <R> R getUiObject(final String uiName, final Class<R> uiClass) {
        if (uiName == null) {
            throw new IllegalArgumentException("editorName cannot be null");
        }
        if (uiClass == null) {
            throw new IllegalArgumentException("rClass cannot be null");
        }

        if (uiName.equals(MISSING_DETAIL_UI_OBJECT) && JPanel.class.isAssignableFrom(uiClass)) {
            return uiClass.cast(new MissingSalesForceConnectionDetailPanel(this));
        } else if (uiName.equals(CREATE_UI_OBJECT) && JPanel.class.isAssignableFrom(uiClass)) {
            return uiClass.cast(new SalesForceConnectionPropertiesPanel());
        }
        return null;
    }
}