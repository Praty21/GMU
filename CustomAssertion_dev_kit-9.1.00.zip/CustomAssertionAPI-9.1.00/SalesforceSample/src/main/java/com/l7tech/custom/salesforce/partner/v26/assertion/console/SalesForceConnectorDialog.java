package com.l7tech.custom.salesforce.partner.v26.assertion.console;

import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceConnection;
import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceConnectorCustomAssertion;
import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceCustomExtensionInterface;
import com.l7tech.custom.salesforce.partner.v26.assertion.util.SalesForceConnectionUtils;
import com.l7tech.policy.assertion.ext.*;
import com.l7tech.policy.assertion.ext.cei.CustomExtensionInterfaceFinder;
import com.l7tech.policy.assertion.ext.commonui.CommonUIServices;
import com.l7tech.policy.assertion.ext.commonui.CustomTargetVariablePanel;
import com.l7tech.policy.assertion.ext.store.KeyValueStoreServices;
import com.l7tech.policy.assertion.ext.targetable.CustomMessageTargetableSupport;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Salesforce Connection Custom Assertion properties dialog.
 */
public class SalesForceConnectorDialog extends JDialog implements AssertionEditor {
    private static final Logger logger = Logger.getLogger(SalesForceConnectorDialog.class.getName());

    private JPanel mainPanel;
    private JComboBox<String> connectionComboBox;
    private JButton okButton;
    private JTabbedPane tabbedPane;
    private JComboBox<String> sObjectComboBox;
    private JButton loginButton;
    private JTextField expandContextVariableField;
    private JLabel imageLabel;
    private JLabel imageMessageLabel;
    private JPanel variablePrefixPanelHolder;

    // Source target message panel
    private JPanel messageSourceVariablePanelHolder;
    private CustomTargetVariablePanel messageSourceVariablePanel;

    // Destination target message panel
    private JPanel messageDestinationVariablePanelHolder;
    private JCheckBox isCredentialSourceCheckBox;
    private CustomTargetVariablePanel messageDestinationVariablePanel;

    private CustomTargetVariablePanel customTargetVariablePanel;

    private SalesForceConnectorCustomAssertion salesForceConnectorCustomAssertion;
    private AssertionEditorSupport editorSupport;
    private String[] describeGlobal;
    private Map consoleContext;

    private Map<String, String> connectionKeys = new HashMap<String, String>();

    // use main method for development
    public static void main(String[] args) {
        SalesForceConnectorCustomAssertion assertion = new SalesForceConnectorCustomAssertion();
        assertion.setsObject("Opportunity");
        new SalesForceConnectorDialog(assertion, new HashMap(0)).edit();
    }

    public SalesForceConnectorDialog(SalesForceConnectorCustomAssertion salesForceConnectorCustomAssertion, Map consoleContext) {
        super(Frame.getFrames().length > 0 ? Frame.getFrames()[0] : null, true);
        this.setTitle("Salesforce Connector");
        this.salesForceConnectorCustomAssertion = salesForceConnectorCustomAssertion;
        this.editorSupport = new AssertionEditorSupport(this);
        this.consoleContext = consoleContext;

        init();
        modelToView(this.salesForceConnectorCustomAssertion);
        enableOrDisableComponents();
        this.setLayout(new BorderLayout());
        this.add(mainPanel, BorderLayout.CENTER);
        this.pack();
    }

    public void edit() {
        this.setVisible(true);
    }

    public void addEditListener(EditListener listener) {
        this.editorSupport.addListener(listener);
    }

    public void removeEditListener(EditListener listener) {
        this.editorSupport.removeListener(listener);
    }

    // PRIVATE METHODS

    private void viewToModel(SalesForceConnectorCustomAssertion model) {
        model.setConnectionKey(connectionKeys.get((String)connectionComboBox.getSelectedItem()));
        model.setsObject((String) sObjectComboBox.getSelectedItem());
        model.setExpandContextVariable(expandContextVariableField.getText());
        model.setVariablePrefix(customTargetVariablePanel.getVariable());

        // setup source message targetable
        CustomMessageTargetableSupport sourceTarget = salesForceConnectorCustomAssertion.getSourceTarget();
        sourceTarget.setTargetMessageVariable(messageSourceVariablePanel.getVariable());
        sourceTarget.setSourceUsedByGateway(true);
        sourceTarget.setTargetModifiedByGateway(true);

        // setup destination message targetable
        CustomMessageTargetableSupport destinationTarget = salesForceConnectorCustomAssertion.getDestinationTarget();
        destinationTarget.setTargetMessageVariable(messageDestinationVariablePanel.getVariable());
        destinationTarget.setSourceUsedByGateway(true);
        destinationTarget.setTargetModifiedByGateway(true);

        // credential source
        model.setCredentialSource(isCredentialSourceCheckBox.isSelected());
    }

    private void modelToView(SalesForceConnectorCustomAssertion model) {
        connectionComboBox.setSelectedItem(null);
        String connectionKey = model.getConnectionKey();
        if (connectionKey != null) {
            for (Map.Entry<String, String> entry : connectionKeys.entrySet()) {
                if (entry.getValue().equals(connectionKey)) {
                    connectionComboBox.setSelectedItem(entry.getKey());
                }
            }
        }

        String[] stringArray = {model.getsObject()};
        sObjectComboBox.setModel(new DefaultComboBoxModel<String>(stringArray));
        sObjectComboBox.setSelectedItem(model.getsObject());
        expandContextVariableField.setText(model.getExpandContextVariable());
        customTargetVariablePanel.setSuffixes(model.getVariableSuffixes());
        customTargetVariablePanel.setVariable(model.getVariablePrefix());

        // setup source/destination message targetable
        messageSourceVariablePanel.setVariable(model.getSourceTarget().getTargetMessageVariable());
        messageDestinationVariablePanel.setVariable(model.getDestinationTarget().getTargetMessageVariable());

        // credential source
        isCredentialSourceCheckBox.setSelected(model.isCredentialSource());
    }

    private void init() {
        connectionKeys.clear();

        // Populate Salesforce Connections Combo Box.
        //
        Map<String, byte[]> connections =
            this.getKeyValueStoreUIServices().getKeyValueStore().findAllWithKeyPrefix(SalesForceConnectionUtils.SALESFORCE_CONNECTION_NAME_PREFIX);

        // Remove disabled connections.
        //
        for (Map.Entry<String, byte[]> entry : connections.entrySet()) {
            final SalesForceConnection connection = SalesForceConnectionUtils.fromBytes(entry.getValue());
            final String connectionName = connection != null ? connection.getConnectionName() : null;
            if (connection == null || connectionName == null) {
              logger.log(Level.FINE, "Ignoring null connection retrieved from Key Value Store: " + entry.getKey());
            } else if(connection.isEnabled()) {
                connectionKeys.put(connectionName, entry.getKey());
            } else {
                // Connection is disabled. Nothing to do.
            }
        }

        // Sort by key.
        //
        java.util.List<String> sortedConnectionNames = new ArrayList<String>(connectionKeys.keySet());
        Collections.sort(sortedConnectionNames);

        // Add to combo box.
        //
        for (String connectionName : sortedConnectionNames) {
            connectionComboBox.addItem(connectionName);
        }

        ActionListener actionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enableOrDisableComponents();
            }
        };

        connectionComboBox.addActionListener(actionListener);

        sObjectComboBox.addActionListener(actionListener);

        imageLabel.setIcon(new ImageIcon(getClass().getClassLoader().getResource("icon.salesforce.32.png")));
        imageMessageLabel.setText("(image located in Salesforce jar)");

        ChangeListener changeListener = new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                enableOrDisableComponents();
            }
        };

        // Target Variable Panel.
        //
        customTargetVariablePanel = this.getCommonUIServices().createTargetVariablePanel();
        customTargetVariablePanel.addChangeListener(changeListener);
        variablePrefixPanelHolder.setLayout(new BorderLayout());
        variablePrefixPanelHolder.add(customTargetVariablePanel.getPanel(), BorderLayout.CENTER);

        // setup source
        messageSourceVariablePanel = this.getCommonUIServices().createTargetVariablePanel();
        messageSourceVariablePanel.setValueWillBeRead(true);
        messageSourceVariablePanel.setValueWillBeWritten(false);
        messageSourceVariablePanel.setAlwaysPermitSyntax(true);
        messageSourceVariablePanel.addChangeListener(changeListener);
        messageSourceVariablePanelHolder.setLayout(new BorderLayout());
        messageSourceVariablePanelHolder.add(messageSourceVariablePanel.getPanel(), BorderLayout.PAGE_START);

        // setup destination
        messageDestinationVariablePanel = this.getCommonUIServices().createTargetVariablePanel();
        messageDestinationVariablePanel.addChangeListener(changeListener);
        messageDestinationVariablePanelHolder.setLayout(new BorderLayout());
        messageDestinationVariablePanelHolder.add(messageDestinationVariablePanel.getPanel(), BorderLayout.PAGE_START);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (connectionComboBox.getSelectedIndex() < 0) return;

                final String connectionName = (String) connectionComboBox.getSelectedItem();
                final String connectionKey = connectionKeys.get(connectionName);

                try {
                    logger.log(Level.INFO, "Invoke method on server side, this log entry will appear in the Policy Manager log.");
                    describeGlobal = getExtensionInterface().describeGlobal(connectionKey);

                    String savedSObject = (String) sObjectComboBox.getSelectedItem();
                    sObjectComboBox.setModel(new DefaultComboBoxModel<String>(describeGlobal));
                    sObjectComboBox.setSelectedItem(savedSObject);
                    pack();
                } catch (Exception exception) {
                    StringBuffer sb = new StringBuffer();
                    sb.append(exception.getMessage());
                    sb.append(System.getProperty("line.separator"));

                    final Writer stringWriter = new StringWriter();
                    final PrintWriter printWriter = new PrintWriter(stringWriter);
                    exception.printStackTrace(printWriter);
                    sb.append(stringWriter.toString(), 0, 500);

                    JOptionPane.showMessageDialog(SalesForceConnectorDialog.this, sb);

                    logger.log(Level.WARNING, stringWriter.toString());

                    throw new RuntimeException(exception);
                }
                enableOrDisableComponents();
            }
        });

        okButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                viewToModel(salesForceConnectorCustomAssertion);
                editorSupport.fireEditAccepted(salesForceConnectorCustomAssertion);
                dispose();
            }
        });
    }

    private void enableOrDisableComponents() {
        tabbedPane.setEnabledAt(1, describeGlobal != null);
        loginButton.setEnabled(connectionComboBox.getSelectedIndex() != -1);
        sObjectComboBox.setEnabled(describeGlobal != null);

        // Enable or disable the OK button.
        //
        if (connectionComboBox.getSelectedItem() != null &&
            sObjectComboBox.getSelectedItem() != null &&
            customTargetVariablePanel.isEntryValid() &&
            messageSourceVariablePanel.isEntryValid() &&
            messageDestinationVariablePanel.isEntryValid()) {
            okButton.setEnabled(true);
        } else {
            okButton.setEnabled(false);
        }
    }

    private SalesForceCustomExtensionInterface getExtensionInterface() throws ServiceException {
        SalesForceCustomExtensionInterface salesForceCustomExtensionInterface = null;
        CustomExtensionInterfaceFinder extensionInterfaceFinder = (CustomExtensionInterfaceFinder) consoleContext.get(CustomExtensionInterfaceFinder.CONSOLE_CONTEXT_KEY);
        if (extensionInterfaceFinder != null) {
            salesForceCustomExtensionInterface = extensionInterfaceFinder.getExtensionInterface(SalesForceCustomExtensionInterface.class);
        }
        return salesForceCustomExtensionInterface;
    }

    private CommonUIServices getCommonUIServices() {
        return (CommonUIServices) consoleContext.get(CommonUIServices.CONSOLE_CONTEXT_KEY);
    }

    private KeyValueStoreServices getKeyValueStoreUIServices() {
        return (KeyValueStoreServices) consoleContext.get(KeyValueStoreServices.CONSOLE_CONTEXT_KEY);
    }
}
