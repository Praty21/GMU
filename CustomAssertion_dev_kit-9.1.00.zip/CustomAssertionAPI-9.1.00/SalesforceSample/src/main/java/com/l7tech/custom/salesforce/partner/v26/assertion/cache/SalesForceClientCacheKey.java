package com.l7tech.custom.salesforce.partner.v26.assertion.cache;

/**
 * Represents all properties necessary to uniquely identify a Salesforce client in the cache.
 */
final public class SalesForceClientCacheKey {
    private final String connectionKey;
    private final String userName;
    private final String passwordId;
    private final String securityTokenId;

    public SalesForceClientCacheKey(final String connectionKey, final String userName, final String passwordId, final String securityTokenId) {
        this.connectionKey = connectionKey;
        this.userName = userName;
        this.passwordId = passwordId;
        this.securityTokenId = securityTokenId;
    }

    String getConnectionKey() {
        return connectionKey;
    }

    String getUserName() {
        return userName;
    }

    String getPasswordId() {
        return passwordId;
    }

    String getSecurityTokenId() {
        return securityTokenId;
    }

    @SuppressWarnings({ "RedundantIfStatement" })
    @Override
    public boolean equals( final Object o ) {
        if ( this == o ) return true;
        if ( o == null || getClass() != o.getClass() ) return false;

        final SalesForceClientCacheKey that = (SalesForceClientCacheKey) o;

        if (connectionKey != null ? !connectionKey.equals(that.connectionKey) : that.connectionKey != null) return false;
        if (userName != null ? !userName.equals(that.userName) : that.userName != null) return false;
        if (passwordId != null ? !passwordId.equals(that.passwordId) : that.passwordId != null) return false;
        if (securityTokenId != null ? !securityTokenId.equals(that.securityTokenId) : that.securityTokenId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = connectionKey.hashCode();
        result = 31 * result + userName.hashCode();
        result = 31 * result + passwordId.hashCode();
        result = 31 * result + securityTokenId.hashCode();
        return result;
    }

    /**
     * Get a String representation of this key.
     *
     * <p>The representation should include all properties of the key.</p>
     *
     * @return The string representation.
     */
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("SalesForceClientCacheKey[");
        sb.append(getConnectionKey());
        sb.append(',');
        sb.append(getUserName());
        sb.append(',');
        sb.append(getPasswordId());
        sb.append(',');
        sb.append(getSecurityTokenId());
        sb.append("]");

        return sb.toString();
    }
}
