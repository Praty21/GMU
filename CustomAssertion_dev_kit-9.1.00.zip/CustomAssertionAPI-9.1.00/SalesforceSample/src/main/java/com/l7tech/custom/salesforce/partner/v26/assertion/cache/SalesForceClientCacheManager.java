package com.l7tech.custom.salesforce.partner.v26.assertion.cache;

import com.l7tech.custom.salesforce.partner.v26.assertion.SalesForceClient;
import com.l7tech.policy.assertion.ext.ServiceException;
import com.l7tech.policy.assertion.ext.password.SecurePasswordServices;
import com.salesforce.jaxws.InvalidIdFault_Exception;
import com.salesforce.jaxws.LoginFault_Exception;
import com.l7tech.custom.salesforce.partner.v26.assertion.util.Config;
import com.l7tech.custom.salesforce.partner.v26.assertion.util.ManagedTimer;
import com.l7tech.custom.salesforce.partner.v26.assertion.util.TimeUnit;

import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This manager will cache Salesforce client connections.  A Salesforce client connection will get de-referenced if any error occurs during the call. Logout occurs when it's de-referenced.
 * It will also get de-referenced if it's been idle too long (default max idle is 5 minutes) or if it's too old (default max age is 10 minutes).
 * A clean up task performs the cache check by default every is 27937 milliseconds (about 30 seconds).  The default size for cache entries is 100.
 * Default values can be changed by overriding values specified in /opt/SecureSpan/Gateway/node/default/etc/conf/salesforce_connector.properties
 *      salesforce.io.connection.cache.max.age=10
 *      salesforce.io.connection.cache.max.idle.time=5
 *      salesforce.io.connection.cache.size=100
 *      salesforce.io.connection.cache.clean.interval=27937
 *
 * A Salesforce client connection is identified by its key, which is contained in SalesForceClientCacheKey with user name, password, and security token.
 * If a Salesforce client connection is not in cache, a new client is created, login performed and saved.
 * If a client is in cache, reuse the connection without login.
 */
public class SalesForceClientCacheManager {
    private static final Logger logger = Logger.getLogger(SalesForceClientCacheManager.class.getName());

    protected static final long DEFAULT_CONNECTION_MAX_AGE = TimeUnit.MINUTES.toMillis(10);
    protected static final long DEFAULT_CONNECTION_MAX_IDLE = TimeUnit.MINUTES.toMillis(5);
    protected static final int DEFAULT_CONNECTION_CACHE_SIZE = 100;

    private static final long CACHE_CLEAN_INTERVAL = Config.getInstance().getTimeUnitProperty(Config.SALESFORCE_CONNECTION_CACHE_CLEAN_INTERVAL_PROPERTY, 27937L);

    private static final Object instanceSync = new Object();

    private static SalesForceClientCacheManager instance;

    private final Config config;
    private final ConcurrentHashMap<SalesForceClientCacheKey, CachedConnection> connectionHolder = new ConcurrentHashMap<SalesForceClientCacheKey, CachedConnection>();
    private final AtomicReference<SalesForceClientCacheManagerConfig> cacheConfigReference = new AtomicReference<SalesForceClientCacheManagerConfig>( new SalesForceClientCacheManagerConfig(0,0,100) );
    private final AtomicBoolean active = new AtomicBoolean(true);
    private final SecurePasswordServices securePasswordServices;

    private Timer timer;
    private SalesForceClientFactory salesForceClientFactory;

    /**
     * Get the singleton instance of SalesForceClientCacheManager.
     *
     * @return the singleton instance
     */
    public static SalesForceClientCacheManager getInstance( final Config config, final SecurePasswordServices securePasswordServices ) {
        synchronized ( instanceSync ) {
            if ( instance == null) {
                instance = new SalesForceClientCacheManager( config, securePasswordServices );
                instance.init();
            }
            return instance;
        }
    }

    private SalesForceClientCacheManager(final Config config, final SecurePasswordServices securePasswordServices){
        this.config = config;
        this.securePasswordServices = securePasswordServices;
    }

    private void init() {
        timer = new ManagedTimer("SalesForceClientCacheManager-CacheCleanup-" + System.identityHashCode(this));
        timer.schedule( new CacheCleanupTask(connectionHolder, cacheConfigReference ), 17371, CACHE_CLEAN_INTERVAL );
        salesForceClientFactory = new SalesForceClientFactory();
        updateConfig();
    }

    /**
     * Run a task with the specified Salesforce client.
     *
     * @param callback The callback
     * @throws Exception If an error occurs creating the resources
     */
    public void doWithSalesforceClient(final SalesForceClientCacheKey cacheKey, final SalesforceClientTaskCallback callback) throws Exception
    {
        if ( !active.get() ) throw new RuntimeException("Salesforce outbound cache manager has stopped.");

        CachedConnection cachedConnection = null;
        try {
            cachedConnection = connectionHolder.get(cacheKey);
            if ( cachedConnection == null || !cachedConnection.ref() ) {
                cachedConnection = null;

                synchronized(cacheKey.toString().intern()) { // prevent concurrent creation for a key
                    cachedConnection = connectionHolder.get(cacheKey); // see if someone else created it
                    if (cachedConnection == null || !cachedConnection.ref()) {
                        cachedConnection = null;
                        cachedConnection = newConnection(cacheKey);
                        // increase the reference count for the new connection, since we are using it.
                        cachedConnection.ref();
                    }
                }
            } else {
                cachedConnection.lastAccessTime.set(System.currentTimeMillis()); // update last access time.
            }

            callback.doWork(cachedConnection.salesForceClient);

        } catch (Exception e) {
            evict(connectionHolder, cacheKey, cachedConnection);
            throw e;
        } finally {
            if ( cachedConnection != null ) cachedConnection.unRef();
        }
    }

    /**
     * Invalidate the connection for the given endpoint.
     *
     * <p>The associated connection will not be used by any subsequent users of
     * this instance. The connection will be closed after any current users
     * have completed their work (or more likely failed if the connection is
     * not valid)</p>
     *
     * @param key The key for the connection.
     */
    public void invalidate( final SalesForceClientCacheKey key ) {
        if ( active.get() ) {
            final CachedConnection cachedConnection = connectionHolder.get(key);
            if ( cachedConnection != null ) {
                evict( connectionHolder, key, cachedConnection );
            }
        }
    }

    /**
     * Invalidate connection with given connection key.
     */
    public void invalidate (String connectionKey) {
        if ( active.get() ) {
            for (Map.Entry<SalesForceClientCacheKey, CachedConnection> entry : connectionHolder.entrySet()) {
                SalesForceClientCacheKey key = entry.getKey();
                if (key.getConnectionKey().equals(connectionKey)) {
                    CachedConnection cachedConnection = entry.getValue();
                    if (cachedConnection != null) {
                        evict( connectionHolder, key, cachedConnection);
                    }
                }
            }
        }
    }

    /**
     * Callback interface for Salesforce client tasks.
     */
    public interface SalesforceClientTaskCallback {
        /**
         * Callback to perform work with the given Salesforce client.
         *
         * <p>Exceptions thrown by this class will be propagated to the caller.</p>
         *
         * @throws Exception If an error occurs.
         */
        void doWork(final SalesForceClient salesForceClient) throws Exception;
    }

    /**
     * Clear all connection references
     */
    public void doShutdown() {
        logger.info( "Shutting down connection cache." );

        timer.cancel();
        Collection<CachedConnection> connList = connectionHolder.values();

        for ( final CachedConnection c : connList ) {
            c.unRef();
        }

        connectionHolder.clear();
    }

    class SalesForceClientFactory {
        public SalesForceClient create() throws MalformedURLException {
            return new SalesForceClient();
        }
    }

    /**
     * Used only for unit testing.
     * @param salesForceClientFactory a new salesForceClientFactory for unit testing
     */
    public void setSalesForceClientFactory(SalesForceClientFactory salesForceClientFactory) {
        this.salesForceClientFactory = salesForceClientFactory;
    }

    private CachedConnection newConnection(final SalesForceClientCacheKey cacheKey)
            throws MalformedURLException, InvalidIdFault_Exception, LoginFault_Exception, UnknownHostException, ServiceException {

        // create the new client for the cache manager and login only once
        final SalesForceClient salesForceClient = salesForceClientFactory.create();
        salesForceClient.login(
            cacheKey.getUserName(),
            securePasswordServices.decryptPassword(cacheKey.getPasswordId()),
            securePasswordServices.decryptPassword(cacheKey.getSecurityTokenId()));

        final CachedConnection newConn = new CachedConnection(cacheKey, salesForceClient);

        // server config controlled connection pool props -- may not need this
        if ( cacheConfigReference.get().maximumSize > 0 ) {
            newConn.ref(); // referenced from cache

            // replace connection if the client already exists
            final CachedConnection existingConn = connectionHolder.put(cacheKey, newConn);
            if ( existingConn != null ) {
                existingConn.unRef(); // clear cache reference
            }
        }

        logger.log(Level.INFO, "New Salesforce client connection created for ({0})", new Object[] {newConn.userName});

        return newConn;
    }

    private static void evict( final ConcurrentHashMap<SalesForceClientCacheKey, CachedConnection> connectionHolder,
                               final SalesForceClientCacheKey key,
                               final CachedConnection connection ) {
        if ( connectionHolder.remove( key, connection ) ) {
            connection.unRef(); // clear cache reference
        }
    }

    private void updateConfig() {
        logger.config( "(Re)loading cache configuration." );

        final long maximumAge = config.getTimeUnitProperty(Config.SALESFORCE_CONNECTION_CACHE_MAX_AGE_PROPERTY, DEFAULT_CONNECTION_MAX_AGE );
        final long maximumIdleTime = config.getTimeUnitProperty(Config.SALESFORCE_CONNECTION_CACHE_MAX_IDLE_PROPERTY, DEFAULT_CONNECTION_MAX_IDLE );
        final int maximumSize = config.getIntegerProperty(Config.SALESFORCE_CONNECTION_CACHE_MAX_SIZE_PROPERTY, DEFAULT_CONNECTION_CACHE_SIZE);

        cacheConfigReference.set( new SalesForceClientCacheManagerConfig(
                rangeValidate(maximumAge, DEFAULT_CONNECTION_MAX_AGE, 0L, Long.MAX_VALUE, "Cached Salesforce Client Maximum Age" ),
                rangeValidate(maximumIdleTime, DEFAULT_CONNECTION_MAX_IDLE, 0L, Long.MAX_VALUE, "Cached Salesforce Client Maximum Idle" ),
                rangeValidate(maximumSize, DEFAULT_CONNECTION_CACHE_SIZE, 0, Integer.MAX_VALUE, "Salesforce Client Cache Size" ) )
        );
    }

    private <T extends Number> T rangeValidate( final T value,
                                                final T defaultValue,
                                                final T min,
                                                final T max,
                                                final String description ) {
        T validatedValue;

        if ( value.longValue() < min.longValue() ) {
            logger.log( Level.WARNING,
                    "Configuration value for {0} is invalid ({1} minimum is {2}), using default value ({3}).",
                    new Object[]{description, value, min, defaultValue} );
            validatedValue = defaultValue;
        } else if ( value.longValue() > max.longValue() ) {
            logger.log( Level.WARNING,
                    "Configuration value for {0} is invalid ({1} maximum is {2}), using default value ({3}).",
                    new Object[]{description, value, max, defaultValue} );
            validatedValue = defaultValue;
        } else {
            validatedValue = value;
        }

        return validatedValue;
    }

    private static class CachedConnection {
        private final AtomicInteger referenceCount = new AtomicInteger(0);
        private final long createdTime = System.currentTimeMillis();
        private final AtomicLong lastAccessTime = new AtomicLong(createdTime);

        private final SalesForceClient salesForceClient;
        private final String userName;

        CachedConnection( final SalesForceClientCacheKey key, final SalesForceClient salesForceClient ) {
            this.salesForceClient = salesForceClient;
            this.userName = key.getUserName();
        }

        /**
         * Once a connection is in the cache a return of false from this
         * method indicates that the connection is invalid and should not be used.
         */
        public boolean ref() {
            return referenceCount.getAndIncrement() > 0;
        }

        public void unRef() {
            int references = referenceCount.decrementAndGet();
            if ( references <= 0 ) {
                logger.log(Level.INFO, "Closing Salesforce client connection for ({0})", new Object[] {userName});
                salesForceClient.logout();
            }
        }
    }

    /**
     * Bean for cache configuration.
     */
    private static final class SalesForceClientCacheManagerConfig {
        private final long maximumAge;
        private final long maximumIdleTime;
        private final int maximumSize;

        private SalesForceClientCacheManagerConfig( final long maximumAge,
                                         final long maximumIdleTime,
                                         final int maximumSize ) {
            this.maximumAge = maximumAge;
            this.maximumIdleTime = maximumIdleTime;
            this.maximumSize = maximumSize;
        }
    }

    /**
     * Timer task to remove idle, expired or surplus connections from the cache.
     *
     * <p>When the cache size is exceeded the oldest connections are removed first.</p>
     */
    private static final class CacheCleanupTask extends TimerTask {
        private static final Logger taskLogger = Logger.getLogger(CacheCleanupTask.class.getName());

        private final ConcurrentHashMap<SalesForceClientCacheKey, CachedConnection> connectionHolder;
        private final AtomicReference<SalesForceClientCacheManagerConfig> cacheConfigReference;

        private CacheCleanupTask( final ConcurrentHashMap<SalesForceClientCacheKey, CachedConnection> connectionHolder,
                                  final AtomicReference<SalesForceClientCacheManagerConfig> cacheConfigReference ) {
            this.connectionHolder = connectionHolder;
            this.cacheConfigReference = cacheConfigReference;
        }

        @Override
        public void run() {
            final SalesForceClientCacheManagerConfig cacheConfig = cacheConfigReference.get();
            final long timeNow = System.currentTimeMillis();
            final int overSize = connectionHolder.size() - cacheConfig.maximumSize;
            final Set<Map.Entry<SalesForceClientCacheKey,CachedConnection>> evictionCandidates =
                    new TreeSet<Map.Entry<SalesForceClientCacheKey, CachedConnection>>(
                            new Comparator<Map.Entry<SalesForceClientCacheKey,CachedConnection>>(){
                                @Override
                                public int compare( final Map.Entry<SalesForceClientCacheKey, CachedConnection> e1,
                                                    final Map.Entry<SalesForceClientCacheKey, CachedConnection> e2 ) {
                                    return Long.valueOf( e1.getValue().createdTime ).compareTo( e2.getValue().createdTime );
                                }
                            }
                    );

            for ( final Map.Entry<SalesForceClientCacheKey, CachedConnection> cachedConnectionEntry : connectionHolder.entrySet() ) {
                if ( (timeNow-cachedConnectionEntry.getValue().createdTime) > cacheConfig.maximumAge && cacheConfig.maximumAge > 0) {
                    evict( connectionHolder, cachedConnectionEntry.getKey(), cachedConnectionEntry.getValue() );
                    taskLogger.log(Level.FINEST, "Evicting Salesforce client connection for ({0}) due to max age exceeded", new Object[] {cachedConnectionEntry.getKey().getUserName()});

                } else if ( (timeNow-cachedConnectionEntry.getValue().lastAccessTime.get()) > cacheConfig.maximumIdleTime && cacheConfig.maximumIdleTime > 0) {
                    evict( connectionHolder, cachedConnectionEntry.getKey(), cachedConnectionEntry.getValue() );
                    taskLogger.log(Level.FINEST, "Evicting Salesforce client connection for ({0}) due to max idle time exceeded",  new Object[] {cachedConnectionEntry.getKey().getUserName()});

                } else if ( overSize > 0 ) {
                    evictionCandidates.add( cachedConnectionEntry );
                }
            }

            // evict oldest first to reduce cache size
            final Iterator<Map.Entry<SalesForceClientCacheKey, CachedConnection>> evictionIterator = evictionCandidates.iterator();
            for ( int i=0; i<overSize && evictionIterator.hasNext(); i++ ) {
                final Map.Entry<SalesForceClientCacheKey, CachedConnection> cachedConnectionEntry = evictionIterator.next();
                evict( connectionHolder, cachedConnectionEntry.getKey(), cachedConnectionEntry.getValue() );
            }
        }
    }
}
