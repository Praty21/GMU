Custom Assertions
-----------------

Custom Assertions are modules that can be added to a SecureSpan Gateway in
order to add functionality to a policy execution that is not already possible
using the existing Assertion palette. Custom Assertions typically implement
proprietary business logic as opposed to standard compliant mechanisms.

Writing your own Custom Assertion comes down to implementing two interfaces:
1.	com.l7tech.policy.assertion.ext.CustomAssertion
2.	com.l7tech.policy.assertion.ext.ServiceInvocation

Both those interfaces as well as other dependencies are included in the
provided "layer7-api-<version>.jar". The CustomAssertion implementation acts as a
bean that describes the data which is configured by the administrator in
the SecureSpan Manager when the policy is being authored. On the other hand
the ServiceInvocation implementation is instantiated by the SecureSpan
Gateway and is invoked at policy runtime execution. When the SecureSpan Gateway
instantiates the custom ServiceInvocation implementation, the CustomAssertion
implementation object is passed so that the runtime executor of the assertion
has the data added by the administrator.


Traffic Logger Sample Custom Assertion
--------------------------------------

The traffic logger sample custom assertion is an example of a custom assertion
which logs information about each requests in a configurable output file. You
will find the sources in the src directory.


Building the project
--------------------

To build the project, you should simply have to run build.sh from the root of
the project.


Installation of a Custom Assertion on a SecureSpan Gateway
----------------------------------------------------------

A Custom Assertion should be package into a jar library. Building the traffic
logger code will produce such a jar. This jar should contain the source code
of the Custom Assertion as well as a custom_assertions.properties providing
details on the Custom Assertion included in the jar. Look at the sample's
version of this file for reference on the format to use. Once this jar is
built, you can install the Custom Assertion following these steps:
1.	stop the SecureSpan Gateway (service ssg stop)
2.	place the custom assertion jar in /opt/SecureSpan/Gateway/runtime/modules/lib
    (make sure owner and permissions are ok)
3.	in the case of the sample provided you must add the
    sampletrafficloggerca.properties file in /opt/SecureSpan/Gateway/node/default/etc/conf
4.	place any libraries that are needed by the Custom Assertion (for example, .so files or .dll files) in /opt/SecureSpan/Gateway/runtime/lib
5.	restart the SecureSpan Gateway (service ssg start)


Modular Packaging and Installation of a Custom Assertion
--------------------------------------------------------

It is also possible to package a Custom Assertion with a set accompanying libraries. In
order to minimize conflicts with the SecureSpan Gateway, these modular Custom Assertion
have their dedicated class loader.

Modular Custom Assertions are packaged in one jar file. This jar file is structured as such:
1. classes in the root of the jar (same as normal jar)
2. a lib directory in the root of the jar includes other jars that the code requires
3. a custom_assertions.properties file also in the root of the jar

To install such a custom assertion in a SecureSpan Gateway, drop this jar into
/opt/SecureSpan/Gateway/runtime/modules/lib

How to use sample
-----------------

Once the Custom Assertion is installed, you can add the Traffic Logger assertion
in a policy. When the assertion is invoked, it will append logs to the traffic
log file. You can customize the content of what is logged in the properties of
the assertion from the SecureSpan Manager policy editor. You can change the path
of the file that receives these log entries in the configuration file
/opt/SecureSpan/Gateway/node/default/etc/conf/sampletrafficloggerca.properties.


Changes since version 3.5
-------------------------

1. Since version 3.6, no additional steps are necessary to install the Custom
Assertion to the SecureSpan Manager. The SecureSpan Gateway will automatically
inform the SecureSpan Manager about the installed Custom Assertions.

2. There is no longer a single custom_assertions.properties file which records
all available Custom Assertions on the system. Instead, each Custom Assertion
includes its own properties file inside its jar and the SecureSpan Gateway automatically
discovers Custom Assertions using the class loader.
