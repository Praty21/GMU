package com.l7tech.samples.customassertion.trafficlogger;

import com.l7tech.policy.assertion.ext.ServiceInvocation;
import com.l7tech.policy.assertion.ext.CustomAssertion;
import com.l7tech.policy.assertion.ext.ServiceRequest;
import com.l7tech.policy.assertion.ext.ServiceResponse;
import com.l7tech.samples.utils.ContextVariablesUtils;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;

import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.security.GeneralSecurityException;
import java.util.logging.Logger;

import org.w3c.dom.Node;
import org.w3c.dom.Document;

/**
 * This is the class that gets instantiated in the server-side policy (ssg) and executed
 * during message processing. In this sample, it will record request information and flush
 * these records at configurable intervals to a configurable file.
 * <p/>
 * <p/>
 * <br/><br/>
 * LAYER 7 TECHNOLOGIES, INC<br/>
 * User: flascell<br/>
 * Date: Jun 2, 2006<br/>
 */
public class TrafficLoggerServiceInvocation extends ServiceInvocation {
    private static final Logger logger = Logger.getLogger(TrafficLoggerServiceInvocation.class.getName());
    private TrafficLoggerCustomAssertion data;
    private String[] vars;

    /**
     * when the server side policy is created, the ssg will pass the custom assertion containing the data
     * (if any) that was entered by the administrator
     */
    public void setCustomAssertion(CustomAssertion customAssertion) {
        super.setCustomAssertion(customAssertion);
        assert(customAssertion instanceof TrafficLoggerCustomAssertion);
        data = (TrafficLoggerCustomAssertion)customAssertion;
        if (data.getInfoToLog() != null) {
            vars = ContextVariablesUtils.getReferencedNames(data.getInfoToLog());
        } else {
            vars = new String[0];
        }
    }

    /**
     * if this assertion is invoked BEFORE routing occurs, this method will be called otherwise. onResponse will
     * be called instead.
     */
    public void onRequest(ServiceRequest serviceRequest) throws IOException, GeneralSecurityException {
        final ServiceRequest cntx = serviceRequest;
        String output = data.getInfoToLog();
        if (vars.length > 0) {
            output = ContextVariablesUtils.resolveString(output, vars, new ContextVariablesUtils.VarGetter() {
                public String getVal(String key) {
                    Object o = cntx.getVariable(key);
                    if (o == null) {
                        logger.info("expected variable " + key + " yields null");
                        return "";
                    } else {
                        return o.toString();
                    }
                }
            });
        }
        if (data.isIncludeMessage()) {
            output = output + " " + nodeToString(serviceRequest.getDocument());
        }
        FileOutputManager.getInstance().record(output);
    }

    /**
     * if this assertion is invoked AFTER routing occurs, this method will be called. otherwise onRequest will
     * be called instead.
     */
    public void onResponse(ServiceResponse serviceResponse) throws IOException, GeneralSecurityException {
        final ServiceResponse cntx = serviceResponse;
        String output = data.getInfoToLog();
        if (vars.length > 0) {
            output = ContextVariablesUtils.resolveString(output, vars, new ContextVariablesUtils.VarGetter() {
                public String getVal(String key) {
                    Object o = cntx.getVariable(key);
                    if (o == null) {
                        logger.info("expected variable " + key + " yields null");
                        return "";
                    } else {
                        return o.toString();
                    }
                }
            });
        }
        if (data.isIncludeMessage()) {
            output = output + " " + nodeToString(serviceResponse.getDocument());
        }
        FileOutputManager.getInstance().record(output);
    }

    public static String nodeToString(Document doc) throws IOException {
        final ByteArrayOutputStream out = new ByteArrayOutputStream(1024);
        try {
            XMLSerializer s = new XMLSerializer();
            s.setOutputByteStream(out);
            s.serialize(doc);
            return out.toString();
        } finally {
            out.close();
        }
    }
}
