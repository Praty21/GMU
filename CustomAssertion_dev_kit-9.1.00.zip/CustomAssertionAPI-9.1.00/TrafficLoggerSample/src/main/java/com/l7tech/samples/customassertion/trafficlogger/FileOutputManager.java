package com.l7tech.samples.customassertion.trafficlogger;

import com.l7tech.samples.utils.Config;

import java.util.ArrayList;
import java.util.TimerTask;
import java.util.Timer;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.concurrent.locks.Lock;
import java.io.FileOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Something that keeps records in memory and flushes them to a file once in a while.
 * <p/>
 * <p/>
 * <br/><br/>
 * LAYER 7 TECHNOLOGIES, INC<br/>
 * User: flascell<br/>
 * Date: Jun 2, 2006<br/>
 */
public class FileOutputManager {
    private final ArrayList<String> data = new ArrayList<String>();
    private final ReadWriteLock rwlock = new ReentrantReadWriteLock();
    private boolean running = false;
    private String outputpath;
    private long maxoutputsize;
    private static final Logger logger = Logger.getLogger(FileOutputManager.class.getName());
    private final Timer flusher = new Timer(true);
    // todo, what if records come in in last 10 seconds prior to shutdown? test and fix if this becomes prod

    public static FileOutputManager getInstance() {
        return SingletonHolder.singleton;
    }

    public void record(String lineToRecord) {
        if (!lineToRecord.endsWith("\n")) {
            lineToRecord = lineToRecord + "\n";
        }
        Lock readLock = rwlock.readLock();
        readLock.lock();
        try {
            data.add(lineToRecord);
        } finally {
            readLock.unlock();
        }
    }

    private void flushToFile() {
        // todo, remove this
        logger.finest("flushing to file");
        //

        Lock writeLock = rwlock.writeLock();
        writeLock.lock();
        try {
            File f = new File(outputpath);
            if (f.length() >= maxoutputsize) {
                logger.info("rotating file");
                f.renameTo(new File(outputpath + ".rotated"));
            }
            FileOutputStream fos = null;
            try {
                fos = new FileOutputStream(outputpath, true);
            } catch (FileNotFoundException e) {
                logger.log(Level.WARNING, "could not open traffic output file. records will be lost", e);
                data.clear();
                return;
            }
            try {
                for (String line : data) {
                    try {
                        fos.write(line.getBytes());
                    } catch (IOException e) {
                        logger.log(Level.WARNING, "could not write to file (" + line.length() + " bytes)", e);
                    }
                }
            } finally {
                try {
                    fos.close();
                } catch (IOException e) {
                    logger.log(Level.WARNING, "problem closing file handle", e);
                }
            }
            data.clear();
        } finally {
            writeLock.unlock();
        }
    }

    /**
     * private constructor, use getInstance to get such an object
     */
    private FileOutputManager() {
        // get the file name
        outputpath = Config.getInstance().getProperties().getProperty(Config.LOGGERPATH);
        if (outputpath == null || outputpath.length() < 1) {
            outputpath = "/ssg/logs/traffic.log";
        }
        try {
            String tmp = Config.getInstance().getProperties().getProperty(Config.MAXOUTPUTLENGTH);
            maxoutputsize = Long.parseLong(tmp);
        } catch (NumberFormatException e) {
            logger.log(Level.WARNING, "bad format for setting " + Config.MAXOUTPUTLENGTH, e);
            maxoutputsize = 0;
        }
        if (maxoutputsize <= 0) {
            maxoutputsize = 5242880;
        }

        // start the worker thread
        if (!running) {
            final FileOutputManager tasker = this;
            TimerTask task = new TimerTask() {
                public void run() {
                    tasker.flushToFile();
                }
            };
            // flush every 10 seconds, could be made configurable through properties file
            flusher.schedule(task, 10000, 10000);
            running = true;
        }
    }

    private static class SingletonHolder {
        private static final FileOutputManager singleton = new FileOutputManager();
    }
}
