package com.l7tech.samples.utils;

import java.util.Properties;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.io.FileInputStream;
import java.io.File;
import java.io.IOException;


/**
 * A util class to retrieve config file properties
 * <p/>
 * <p/>
 * <br/><br/>
 * LAYER 7 TECHNOLOGIES, INC<br/>
 * User: flascell<br/>
 * Date: Jun 2, 2006<br/>
 */
public class Config {
    public static final String LOGGERPATH = "loggerpath";
    public static final String MAXOUTPUTLENGTH = "maxfilesizeinbytes";

    private static final Logger logger = Logger.getLogger(Config.class.getName());
    final static String TRAFFICLOGGER_CONFIG_FILENAME = "sampletrafficloggerca.properties";

    private static Config instance = null;
    private Properties properties = null;

    /**
     * this class cannot be instantiated
     */
    private Config() {
        String ssgConfigPath = System.getProperty("ssg.config.dir", "/ssg/etc/conf");
        String propertiesFile = ssgConfigPath + "/" + Config.TRAFFICLOGGER_CONFIG_FILENAME;
        properties = Config.retrieveProperties(propertiesFile);
    }

    public static Config getInstance() {
        if (instance == null) {
            instance = new Config();
        }
        return instance;
    }

    public Properties getProperties() {
        return properties;
    }

    private static Properties retrieveProperties(String caPropertiesFile) {
        Properties props = new Properties();
        if (caPropertiesFile == null) {
            String msg = "Couldn't load properties";
            logger.severe(msg);
            throw new RuntimeException(msg);
        }

        FileInputStream propStream = null;
        try {
            propStream = null;

            File file = new File(caPropertiesFile);
            if (file.exists()) {
                propStream = new FileInputStream(file);
                props.load(propStream);
                logger.info("Loading properties from " + caPropertiesFile);
                return props;
            } else {
                logger.severe(caPropertiesFile + " not found");
                throw new RuntimeException("Couldn't load " + caPropertiesFile + ", File not found!");
            }

        } catch (IOException ioe) {
            logger.severe("Couldn't load " + caPropertiesFile);
            throw new RuntimeException("Couldn't load " + caPropertiesFile);
        } finally {
            if (propStream != null) {
                try {
                    propStream.close();
                } catch (IOException e) {
                    logger.log(Level.WARNING, "io error", e);
                }
            }
        }
    }
}
