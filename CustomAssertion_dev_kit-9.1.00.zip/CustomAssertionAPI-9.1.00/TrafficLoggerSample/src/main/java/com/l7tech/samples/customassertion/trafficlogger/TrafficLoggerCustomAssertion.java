package com.l7tech.samples.customassertion.trafficlogger;

import com.l7tech.policy.assertion.ext.CustomAssertion;
import com.l7tech.policy.assertion.UsesVariables;
import com.l7tech.policy.assertion.SetsVariables;
import com.l7tech.policy.variable.VariableMetadata;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Sample Custom Assertion to log traffic information to a specific file. The bean properties exposed here are
 * used in the Manager to know what to use in the gui.
 * <p/>
 * <p/>
 * <br/><br/>
 * LAYER 7 TECHNOLOGIES, INC<br/>
 * User: flascell<br/>
 * Date: Jun 2, 2006<br/>
 */
public class TrafficLoggerCustomAssertion implements CustomAssertion, UsesVariables, SetsVariables {
    private static final String DEFAULT = "${gateway.time} ${request.soap.namespace} " +
                                          "${request.soap.operationname} ${request.authenticateduser} " +
                                          "${service.url} ${httpRouting.latency}";
    private String infoToLog = DEFAULT;
    private boolean includeMessage;

    public String getName() {
        return "Traffic Logger";
    }

    public String getInfoToLog() {
        return infoToLog;
    }

    public void setInfoToLog(String infoToLog) {
        this.infoToLog = infoToLog;
    }

    public boolean isIncludeMessage() {
        return includeMessage;
    }

    public void setIncludeMessage(boolean includeMessage) {
        this.includeMessage = includeMessage;
    }

    public String[] getVariablesUsed() {
        if (infoToLog == null) return new String[]{};
        return getReferencedNames(infoToLog);
    }

    public VariableMetadata[] getVariablesSet() {
        // this custom assertion does not happen to be setting context variables
        return new VariableMetadata[] {
                /*
                new VariableMetadata("sampleca.foo1"),
                new VariableMetadata("sampleca.foo2"),
                new VariableMetadata("sampleca.foo3")
                */
        };
    }

    // this had to be pulled out of contextvariablesutils cause that class isn't available to ssm at runtime (bah!)
    private static final String REGEX_PREFIX = "(?:\\$\\{)";
    private static final String REGEX_SUFFIX = "(?:\\})";
    private static final Pattern regexPattern = Pattern.compile(REGEX_PREFIX +"(.+?)"+REGEX_SUFFIX);

    private String[] getReferencedNames(String s) {
        if (s == null) {
            throw new IllegalArgumentException();
        }
        ArrayList vars = new ArrayList();
        Matcher matcher = regexPattern.matcher(s);
        while (matcher.find()) {
            int count = matcher.groupCount();
            if (count != 1) {
                throw new IllegalStateException("Expecting 1 matching group, received: "+count);
            }
            String var = matcher.group(1);
            vars.add(var);
        }
        return (String[])vars.toArray(new String[0]);
    }
}
